﻿using System;
using System.Collections.Generic;
using de.jmu.ge.SpokeSceneImporter;
using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class OnCollisionEvent : LogicEvent
    {
        public OnCollisionEvent(string name, ParameterList parameters, List<ActionSequenceComponent> actionSequence)
        {
            this.name = name;
            this.parameters = parameters;
            this.actionSequence = actionSequence;
        }

        public override void OnConfigureLogic()
        {
            GameObject gameObject = Utils.FindGameObjectWithID((UniqueIdParameter)parameters.getParameterValueByName("gameObject"));
            OnCollisionComponent component = gameObject.AddComponent<OnCollisionComponent>();
            component.uuid = (string)parameters.getParameterValueByName("other");
            component.onCollisionEvent = this;
        }
    }
}