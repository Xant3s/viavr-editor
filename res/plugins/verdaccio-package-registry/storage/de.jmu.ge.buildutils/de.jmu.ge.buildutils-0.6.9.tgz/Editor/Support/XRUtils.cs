using System.Collections.Generic;
using UnityEditor;
using UnityEditor.XR.Management;
using UnityEngine;
using UnityEngine.XR.Management;

namespace de.jmu.ge.BuildUtils.Support {
    public class XRUtils : MonoBehaviour {
        //Todo: Refactor this to more readable
        public static void SetXRLoader(BuildTargetGroup targetGroup, string loader, string xrLoaderSearchPath) {
            var settingsForBuildTarget = XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(targetGroup);

            if(settingsForBuildTarget == null) {
                settingsForBuildTarget = ScriptableObject.CreateInstance<XRGeneralSettings>();
                XRGeneralSettings.Instance =  settingsForBuildTarget;
            }

            if(settingsForBuildTarget.Manager == null) {
                var newManagerSettings = ScriptableObject.CreateInstance<XRManagerSettings>();
                settingsForBuildTarget.Manager = newManagerSettings;
                EditorUtility.SetDirty(settingsForBuildTarget);
            }

            if(loader != null && loader.Trim().Length > 0) {
                var guid = AssetDatabase.FindAssets(loader, new[] { xrLoaderSearchPath })[0];
                var loaderAsset = AssetDatabase.LoadAssetAtPath<XRLoader>(AssetDatabase.GUIDToAssetPath(guid));
                settingsForBuildTarget.Manager.TrySetLoaders(new List<XRLoader> { loaderAsset });
                settingsForBuildTarget.InitManagerOnStart = true;
            } else {
                settingsForBuildTarget.Manager.TrySetLoaders(new List<XRLoader> { });
                settingsForBuildTarget.InitManagerOnStart = false;
            }

            EditorUtility.SetDirty(settingsForBuildTarget.Manager);
            AssetDatabase.SaveAssets();
        }
    }
}
