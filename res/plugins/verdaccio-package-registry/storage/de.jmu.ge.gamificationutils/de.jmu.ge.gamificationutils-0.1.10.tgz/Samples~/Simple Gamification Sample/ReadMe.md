# How to Run Sample

When downloading this sample a Sample Editor window will appear and ask you if you want to initialize the downloaded sample.
While pressing `Yes` it will create the Settings folder `Assets/Settings` (if not already present)
and move the downloaded `UIConfiguration.json` file there. (Note: Any present `UIConfiguration.json` file will be overwritten!)

Run this sample by clicking `Tools/Via-VR Unity Bridge/Simulate Unity Bridge Calls` from the menu at the top.
The simulated Call will then initialize a sample UI from scriptable objects (inside `Assets/Settings/States`) and use the `UIConfiguration.json` to set a font and color.
Open the downloaded Sample Scene and press play!

## OPTIONAL
To test if the Content in the UI changes automatically, attach the `ControlUITest.cs` script a Game Object in the scene and reference the states. 
You now can control the scriptable objects value by pressing `I` `J` `K` `L`. 
You should be able to move around with `W` `A` `S` `D`! 
Have fun :)