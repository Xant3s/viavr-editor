﻿using Parameters;
using UnityEngine;
using UnityEngine.PlayerLoop;

namespace de.jmu.ge.Logic.Runtime
{
    public class PlayAnimation : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            UniqueIdParameter id = (UniqueIdParameter)parameters.getParameterValueByName("gameObject");
            GameObject gameObject = Utils.FindGameObjectWithID(id);
            var anim = gameObject.GetComponent<Animator>();
            if (anim != null)
            {
                anim.Play((string)parameters.getParameterValueByName("animation"));
            }
        }
    }
}