using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class DisableGameObjectOfEvent : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            GameObject gameObject = logicEvent.eventGameObject;
            gameObject.SetActive(false);
        }
    }
}