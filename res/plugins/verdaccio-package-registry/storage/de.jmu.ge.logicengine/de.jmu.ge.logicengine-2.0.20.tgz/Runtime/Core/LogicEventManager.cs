using UnityEngine;

public class LogicEventManager : MonoBehaviour {
    // This class needs to  be added to a scene by the logic engine
    // It is responsible to invoke events at the right time

    // All events are saved in Assets/Settings/Events
    // Load them from there? Each event class should define when it is invoked

    // This class should provide unity events for specific stuff? Then the logic events can subscribe to them
    // If new events need to be added, that's difficult
    // Maybe for each LogicEvent there needs to be a corresponding UnityEvent

    // How to do this in the most general way and make it extensible for the future?
    // Examples:
    // OnCollision: two objects. Would need to see all collisions ever or be informed by each object or by a specific object that is important
    //      maybe the first object can be found by uuid and another script added for OnCollision? Then check for the second object and if it fits, invoke the event
    // OnTrigger: two objects. Same as for collisions
    // OnGrab: one object. Would need to access information when something is grabbed
    // OnTimeElapsed: coroutine. that is relatively easy
    // ...
} 