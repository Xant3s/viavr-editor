using System;
using System.Linq;
using de.jmu.ge.BuildUtils.Build;
using de.jmu.ge.BuildUtils.Configuration;
using UnityEditor;

namespace de.jmu.ge.BuildUtils {
    public class PackageConfigurator: viavr.UnityBridge.Core.PackageConfigurator {
        public override void OnPostConfiguration() {
            try {
                SceneImporter.AddScenesToBuildSettings();
                Settings.Current.ActiveBuildConfiguration = BuildManager.GetPicoBuildConfig();
                UnityEditor.Compilation.CompilationPipeline.RequestScriptCompilation();
            }
            catch (Exception e) {
                Console.WriteLine(e);
            }
        }
    }
}