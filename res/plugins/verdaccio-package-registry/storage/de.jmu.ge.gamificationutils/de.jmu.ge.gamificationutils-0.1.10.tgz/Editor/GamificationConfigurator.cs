using System;
using System.Collections.Generic;
using System.Linq;
using de.jmu.ge.Gamification.UI;
using de.jmu.ge.Logic.Editor;
using de.jmu.ge.viavr.UnityBridge.Core;
using Config = de.jmu.ge.Gamification.General.Configuration;
using de.jmu.ge.viavr.UnityBridge.Utils;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using Object = UnityEngine.Object;
using de.jmu.ge.Logic.Runtime;

namespace de.jmu.ge.Gamification.Editor {
    public class GamificationConfigurator : PackageConfigurator {
        private readonly ConfigurationProvider<Config> configProvider = 
            new JsonLoader<Config>("Assets/Settings/de.jmu.ge.gamificationutils/Configuration.json");
        private Config configuration;
        private const string path = "Assets/Resources/Variables/";
        private GameObject ui;

        public override void Init() {
            configuration = configProvider.GetConfiguration();
        }

        public override void OnConfigureScene() {
            Debug.Log("Configure Ui Builder");
            InitUI();
        }

        public override void OnConfigureUI() {
            Object.FindObjectOfType<UiBuilder>().BuildUI();
        }

        private void InitUI() {
            // Find or create UI Game Object
            var uiBuilder = Object.FindObjectOfType<UiBuilder>();
            if(!uiBuilder) {
                // If not create UI Builder obj
                ui = new GameObject {
                    name = "UiBuilder"
                };
                ui.AddComponent<UiBuilder>();
                // Add WorldSpaceUI Document to it
                ui.AddComponent<WorldSpaceUIDocument>();
                // Add VR Canvas to it
                ui.AddComponent<VRCanvas>();
            }
            else {
                ui = uiBuilder.gameObject;
            }
        }        
    }
}
