using UnityEditor;
using UnityEngine;
using de.jmu.ge.BuildUtils.Configuration;


namespace de.jmu.ge.BuildUtils.Editor {
    public class BuildConfigurationSelectionWindow : EditorWindow {
        internal static void Init() {
            var window = (BuildConfigurationSelectionWindow)GetWindow(typeof(BuildConfigurationSelectionWindow));
            window.titleContent = new GUIContent("Build Configuration");
            window.Show();
        }

        private void OnGUI() {
            foreach(var config in BuildConfiguration.GetAvailableConfigurations()) {
                using(new GUILayout.HorizontalScope()) {
                    using(new EditorGUI.DisabledScope(true)) {
                        EditorGUILayout.ObjectField(GUIContent.none, config, typeof(BuildConfiguration), false);
                    }

                    if(GUILayout.Button("Activate", GUILayout.Width(80))) {
                        Close();
                        ManualBuildWindow.ConfigureBuildEditor(config);
                    }
                }
            }
        }
    }
}