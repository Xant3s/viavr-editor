using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Parameter
{
    public enum ParameterType
    {
        TypeNumber,
        TypeString,
        TypeBool
    }


    [SerializeField] private string _name;
    [SerializeField] public ParameterType parameterType;

    [SerializeField] private float _numberValue;
    [SerializeField] private string _stringValue;
    [SerializeField] private bool _boolValue;

    public string Name
    {
        get => _name;
        set
        {
            if (value != _name)
            {
                _name = value;
            }
        }
    }

    public float NumberValue
    {
        get => _numberValue;
        set
        {
            _numberValue = value;
        }
    }

    public string StringValue
    {
        get => _stringValue;
        set
        {
            _stringValue = value;
        }
    }

    public bool BoolValue
    {
        get => _boolValue;
        set
        {
            _boolValue = value;
        }
    }

    public object GetValue()
    {
        switch (parameterType)
        {
            case ParameterType.TypeNumber:
                return NumberValue;
            case ParameterType.TypeString:
                return StringValue;
            case ParameterType.TypeBool:
                return BoolValue;
            default:
                return null;
        }
    }
}
