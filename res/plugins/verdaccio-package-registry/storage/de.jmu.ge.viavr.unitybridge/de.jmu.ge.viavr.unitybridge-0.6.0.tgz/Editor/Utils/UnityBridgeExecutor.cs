using UnityEditor;

namespace de.jmu.ge.viavr.UnityBridge.Utils {

    /// <summary>
    /// This allows you to simulate a call from the VIA-VR editor to the
    /// Unity Bridge from the Unity editor menu.
    /// </summary>
    public static class UnityBridgeExecutor {
        [MenuItem("Tools/VIA-VR Unity Bridge/Simulate Unity Bridge Calls")]
        private static void Execute() {
            Core.UnityBridge.ExecuteAll();
        }
    }
}