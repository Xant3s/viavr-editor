
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[Serializable]
public class ParameterList
{
    [SerializeField] public List<Parameter> parameters = new List<Parameter>();

    public Parameter findParameterByName(string name)
    {
        return parameters.SingleOrDefault(parameter => parameter.Name == name);
    }

    public object getParameterValueByName(string name)
    {
        var parameter = findParameterByName(name);
        return parameter.GetValue();
    }
}