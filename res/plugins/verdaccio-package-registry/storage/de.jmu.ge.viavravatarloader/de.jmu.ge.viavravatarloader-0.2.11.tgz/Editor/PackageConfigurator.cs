using System.Collections.Generic;
using UnityEngine;
using de.jmu.ge.SpokeSceneImporter;
using RealityStack.VirtualHumanRuntimeLoader;
using System;
using UnityEditor;

namespace de.jmu.ge.viavravatarloader
{
    public class PackageConfigurator : viavr.UnityBridge.Core.PackageConfigurator
    {
        private static AvatarLoader _avatarLoader;
        public static GameObject destinationFolder;
        public static GameObject newAvatarObject;

        [System.Serializable]
        public class Avatar
        {
            public string name;
            public string id;
            public string token;
            public string articyId;
            public string sceneObject;
        }

        [System.Serializable]
        public class ObjectTags
        {
            // The object ID is dynamic, so we use a dictionary to map it to tags.
            public Dictionary<string, List<string>> tags;
        }

        [System.Serializable]
        public class RootObject
        {
            public bool supervisorEnabled;
            public List<string> selectedPackages;
            public List<Avatar> avatars;
            public bool useFloorMap;
            public ObjectTags objectTags;
        }


        // TODO: spawn avatars here
        // TODO: spawn avatars here
        public override void SetupScene()
        {
            _avatarLoader = new AvatarLoader();
            Debug.Log("Viavr avatar loader executed SetupScene!");
            CreateEmptyGameObject("object_murat");
            SpawnAvatars(_avatarLoader);
            
        }

        private void CreateEmptyGameObject(string objectName)
        {
            GameObject newObject = new GameObject(objectName);
        }

        private void SpawnAvatars(AvatarLoader newAvatar)
        {
            RootObject rootObject;
            


            // Load build settings
            Debug.Log("Now json file will be uploaded");


            // Load the JSON file from Resources

            string filePath = Application.dataPath + "/Settings/BuildSettings.json";
            if (System.IO.File.Exists(filePath))
            {
                // Read the JSON file from the specified path
                string jsonText = System.IO.File.ReadAllText(filePath);

                // Parse the JSON data into a RootObject instance
                rootObject = JsonUtility.FromJson<RootObject>(jsonText);

                if (rootObject != null)
                {
                    // Check if avatars list is not null and not empty
                    if (rootObject.avatars != null && rootObject.avatars.Count > 0)
                    {
                        foreach (var avatar in rootObject.avatars)
                        {
                            Debug.Log(avatar.name);

                            if (avatar != null && !string.IsNullOrEmpty(avatar.sceneObject) && !string.IsNullOrEmpty(avatar.token))
                            {
                                foreach (var spawnobject in GameObject.FindObjectsOfType<Uuid>())
                                {
                                    newAvatar.OnAvatarConstructed += constructedAvatar =>
                                    {
                                        PositionAvatar(spawnobject.gameObject, constructedAvatar, avatar);
                                    };
                                    
                                    
                                    //if (spawnobject.serializedUuid == avatar.sceneObject)
                                    if (string.Equals(spawnobject.serializedUuid, avatar.sceneObject, StringComparison.OrdinalIgnoreCase))
                                    {
                                        // Check if spawnobject is not null before proceeding
                                        if (spawnobject != null)
                                        {
                                            newAvatar.OnAvatarConstructed += constructedAvatar =>
                                            {
                                                Debug.Log("Now Avatar will be spawned");

                                                // Check if spawnobject is still not null before using it
                                                if (spawnobject != null)
                                                {
                                                    PositionAvatar(spawnobject.gameObject, constructedAvatar, avatar);
                                                    //newAvatarObject = UnityEngine.Object.Instantiate(constructedAvatar);
                                                    Debug.Log("Avatar was spawned");
                                                }
                                                else
                                                {
                                                    Debug.LogError("Spawn object is null. Cannot position the avatar.");
                                                }
                                            };
                                        }
                                        else
                                        {
                                            Debug.LogError("Spawn object is null. Cannot register OnAvatarConstructed event.");
                                        }
                                    }
 
                                }

                                newAvatar.LoadAvatarAsync($"{Application.dataPath}/Avatars/{avatar.token}/result.fbx",
                                    $"{Application.dataPath}/Avatars/{avatar.token}/skin_basecolor.png", destinationFolder);
                            }
                            else
                            {
                                Debug.LogError("Missing UUId value or wrong avatar file name.");
                            }
                        }
                    }
                    else
                    {
                        Debug.LogError("No avatars found in JSON data. Make sure the JSON file includes valid avatar configurations.");
                    }
                }
                else
                {
                    Debug.LogError("Failed to parse JSON data. Check the format of the JSON file.");
                }
            }
            else
            {
                Debug.LogError("Failed to load JSON file:" + filePath);
            }
        }



        public static void PositionAvatar(GameObject spawnGameObject, GameObject constructedAvatar, Avatar avatarData)
        {
            Debug.Log(spawnGameObject.name + " Position will be loaded with Uuid number: " + constructedAvatar.transform.position + constructedAvatar.name);
            constructedAvatar.transform.position = spawnGameObject.transform.position;
            constructedAvatar.transform.rotation = spawnGameObject.transform.rotation;
            
        }
    }
}