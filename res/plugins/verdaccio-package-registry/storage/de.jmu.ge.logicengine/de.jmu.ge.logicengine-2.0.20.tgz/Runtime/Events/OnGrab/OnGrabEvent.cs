﻿using System;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.XR.Interaction.Toolkit;

namespace de.jmu.ge.Logic.Runtime {
    public class OnGrabEvent : LogicEvent {
        public GameObject gameObject;
        private XRGrabInteractable grabInteractable;

        public override void OnConfigureLogic()
        {
            Debug.Log("OnConfigureScene not implemented: OnGrabEvent");
        }

        protected void Start() {
            grabInteractable = gameObject.GetComponent<XRGrabInteractable>();
        }

        private void Update() {
            if(grabInteractable.isSelected) {
                Invoke();
            }
        }
    }
}