using System.IO;
using UnityEngine;

namespace de.jmu.ge.viavr.UnityBridge.Utils {
    public class JsonLoader<T>: ConfigurationProvider<T> {
        private T configuration;

        public JsonLoader(string filePath) {
            LoadConfiguration(filePath);
        }
        
        public T GetConfiguration() => configuration;

        public void LoadConfiguration(string filePath) {
            if(!File.Exists(filePath)) return;
            var json = File.ReadAllText(filePath);
            configuration = JsonUtility.FromJson<T>(json);
        }
        
        public bool HasConfiguration() => configuration != null;
    }
}