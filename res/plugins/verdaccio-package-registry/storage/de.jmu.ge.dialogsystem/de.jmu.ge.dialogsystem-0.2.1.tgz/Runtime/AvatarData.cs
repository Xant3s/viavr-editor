﻿namespace de.jmu.ge.viavr.dialogs.runtime {
    public class AvatarData {
        public string articyId;
        public string name;
        public string token;
        public string sceneObject;
        public string dialogueId;
    }
}