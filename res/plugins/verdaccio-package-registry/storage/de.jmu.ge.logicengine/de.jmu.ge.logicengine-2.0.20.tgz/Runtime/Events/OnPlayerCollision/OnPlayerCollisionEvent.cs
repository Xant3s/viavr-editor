using System;
using de.jmu.ge.SpokeSceneImporter;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class OnPlayerCollisionEvent : LogicEvent
    {
        public override void OnConfigureLogic()
        {
            var camera = Camera.main;
            var collider = camera.GetComponentInParent<Collider>();
            var gameObject = collider.gameObject;
            OnPlayerCollisionComponent component = gameObject.AddComponent<OnPlayerCollisionComponent>();
            component.uuid = (string)parameters.getParameterValueByName("other");
            component.checkTag = (string)parameters.getParameterValueByName("tag");
            component.onPlayerCollisionEvent = this;
        }
    }
}