using System;
using System.Collections.Generic;
using de.jmu.ge.Logic.Runtime;
using JetBrains.Annotations;
using UnityEditor;
using UnityEngine;
using LogicEvent = de.jmu.ge.Logic.Runtime.LogicEvent;

namespace de.jmu.ge.Logic.Editor
{
    public static class EventCreator
    {
        private static string path;
        private static List<LogicEvent> events;

        public static void CreateEvents(List<LogicEvent> existingEvents, [NotNull] IEnumerable<LogicEventJSON> logicEvents, string creationPath)
        {
            events = existingEvents;
            path = creationPath;
            foreach (var logicEvent in logicEvents)
            {
                if (CheckIfEventExists(logicEvent)) continue;
                CreateEvent(logicEvent);
            }
        }

        private static bool CheckIfEventExists(LogicEventJSON logicEvent)
        {
            foreach (var e in events)
            {
                if (e.name.Equals(logicEvent.name))
                {
                    return true;
                }
            }
            return false;
        }

        private static void CreateEvent(LogicEventJSON logicEvent)
        {
            Type type = LogicEventJSON.GetType(logicEvent.name);
            
            var eventComponent = LogicEngineConfigurator.logicEngineGO.AddComponent(type) as LogicEvent;
            eventComponent.name = logicEvent.name;
            eventComponent.parameters = logicEvent.ConvertParametersToList(logicEvent.parameters);
            eventComponent.actionSequence = logicEvent.ConvertActionSequenceComponents(logicEvent.actionSequence);
        }
    }
}