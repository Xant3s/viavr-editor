# Sample Package

This is a minimal example of a Unity package which provides functionality for VIA-VR. Therefore, the package must implement an interface for the VIA-VR editor to call. This interface allows package users to configure the package as they would otherwise via e.g. the Unity inspector.


```bash
Example Package/
├───Package
│   ├───Editor    // Contains both the regular Unity package editor scripts and the ExamplePackageConfigurator, which adds the required GameObject to all scenes.
│   └───Runtime   // The regular Unity package runtime scripts.
└───Scenes        // Exmpty example scenes to be manipulated by the package.
```

See [Unity Bridge Readme](https://gitlab2.informatik.uni-wuerzburg.de/GE/Dev/ViaVR/components/via-vr-unity-bridge/-/blob/main/README.md) for more information.

## How to Run

Select `Tools/VIA-VR Unity Bridge/Simulate Unity Bridge Calls` from the Unity menu. This will simulate a call from the VIA-VR editor. The `OnConfigureScene` method will add a new GameObject to both sample scenes.