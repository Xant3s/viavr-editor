using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

namespace de.jmu.ge.BuildUtils.Support {
    public class FileSupport {
        public delegate string TokenReplacement<T>(T sourceData);

        public const string TemplatePattern = "*.template";

        public class TokenMap<TContext> : Dictionary<string, TokenReplacement<TContext>> { }

        public static string ReplaceTokens<T>(string content, TokenMap<T> replacements, T context) {
            var output = content;
            foreach(var token in replacements) {
                output = output.Replace(token.Key, token.Value(context));
            }

            return output;
        }

        public static void ReplaceTokens<T>(FileInfo file, TokenMap<T> replacements, T context,
            bool deleteSource) {
            string content = File.ReadAllText(file.FullName);
            content = ReplaceTokens(content, replacements, context);
            string targetFilename = Path.Combine(file.DirectoryName, Path.GetFileNameWithoutExtension(file.Name));
            File.WriteAllText(targetFilename, content);
            if(deleteSource)
                file.Delete();
        }

        public static void ReplaceTokensRecursive<T>(DirectoryInfo directory, TokenMap<T> replacements,
            T context, bool deleteSource = false) {
            foreach(FileInfo fi in directory.GetFiles(TemplatePattern)) {
                ReplaceTokens(fi, replacements, context, deleteSource);
            }

            foreach(DirectoryInfo subDir in directory.GetDirectories()) {
                ReplaceTokensRecursive(subDir, replacements, context, deleteSource);
            }
        }

        public static void CopyAll(DirectoryInfo source, DirectoryInfo target,
            string searchPattern = "*", string exclusionPattern = null, bool overwrite = false) {
            if(string.Equals(source.FullName, target.FullName, StringComparison.CurrentCultureIgnoreCase)) {
                return;
            }

            // Check if the target directory exists, if not, create it.
            if(Directory.Exists(target.FullName) == false) {
                Directory.CreateDirectory(target.FullName);
            }

            // Copy each file into it's new directory.
            Regex exclusionRegex = exclusionPattern != null ? new Regex(exclusionPattern) : null;
            foreach(FileInfo fi in source.GetFiles(searchPattern)) {
                if(exclusionPattern == null || !exclusionRegex.IsMatch(fi.Name))
                    fi.CopyTo(Path.Combine(target.ToString(), fi.Name), overwrite);
            }

            // Copy each subdirectory using recursion.
            foreach(DirectoryInfo diSourceSubDir in source.GetDirectories()) {
                DirectoryInfo nextTargetSubDir =
                    target.CreateSubdirectory(diSourceSubDir.Name);
                CopyAll(diSourceSubDir, nextTargetSubDir, searchPattern, exclusionPattern, overwrite);
            }
        }

        public static bool GetRelativePathToRepository(DirectoryInfo directory, out string relativePath) {
            relativePath = "";
            while(directory != null) {
                if(!Directory.Exists(Path.Combine(directory.FullName, ".git"))) {
                    relativePath = Path.Combine(directory.Name, relativePath);
                    directory = directory.Parent;
                    continue;
                }

                return true;
            }

            return false;
        }

        public static bool GetRepositoryRoot(DirectoryInfo directory, out DirectoryInfo gitRoot) {
            while(directory != null) {
                if(!Directory.Exists(Path.Combine(directory.FullName, ".git"))) {
                    directory = directory.Parent;
                    continue;
                }

                gitRoot = directory;
                return true;
            }

            gitRoot = null;
            return false;
        }

        public static string GetAbsolutePathInProjectRoot(string pathRelativeToProjectRoot, bool create = true) {
            var path = Path.GetFullPath(Path.Combine(Application.dataPath, "..", pathRelativeToProjectRoot));
            if(create) {
                Directory.CreateDirectory(path);
            }

            return path;
        }
    }
}