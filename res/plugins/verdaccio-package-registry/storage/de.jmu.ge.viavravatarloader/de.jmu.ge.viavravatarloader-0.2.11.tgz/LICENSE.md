## Copyrights and Dependencys

**AvatarRuntimeLoader:**
 ```
 //=======================================================================================================
 //   Authors: David Mal
 //   Contact: david.mal@uni-wuerzburg.de
 //            
 //   Copyright (C) HCI Group, University of Wuerzburg, Prof. Dr. Marc Erich Latoschik. 
 //=======================================================================================================
```

**NativeAvatarLoader:**
 ```
 //=======================================================================================================
 //   Authors: Timo Menzel, Stephan Wenninger
 //   Contact: timo.menzel@tu-dortmund.de
 //            stephan.wenninger@tu-dortmund.de
 //   
 //   Permission granted for internal use by HCI Group, University of Würzburg by Stephan Wenninger 2021
 //   Copyright (C) Computer Graphics Group, TU Dortmund, Prof. Dr. Mario Botsch.
 //=======================================================================================================
```
**Standalone Filebrowser:**
 ```
 //========================================================================================================
 //   Authors: Gökhan Gökçe
 //   GitHub:  https://github.com/gkngkc/UnityStandaloneFileBrowser (MIT License)
 //            
 //
 //   Copyright (c) 2017 Gökhan Gökçe
 //=======================================================================================================
```
