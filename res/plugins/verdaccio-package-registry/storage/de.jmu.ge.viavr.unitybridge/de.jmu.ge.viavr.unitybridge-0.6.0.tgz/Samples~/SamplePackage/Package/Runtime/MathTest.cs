using UnityEngine;

/// <summary>
/// Provies example functionality.
/// </summary>
public class MathTest : MonoBehaviour {
    private void Update() {
        Debug.Log("hallo world");
    }

    public int Add(int a, int b) => a + b;
}