using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace de.jmu.ge.BuildUtils.Support {
    [Serializable]
    public class OptionalValue<T> {
        public bool enabled;
        public T value;

        public static implicit operator T(OptionalValue<T> ov) => ov.value;

        public void Set(T val) {
            value = val;
            enabled = true;
        }
    }

    [Serializable]
    public class OptionalString : OptionalValue<string> { }

    [Serializable]
    public class OptionalBuildTarget : OptionalValue<BuildTarget> { }

    [Serializable]
    public class OptionalScriptingImplementation : OptionalValue<ScriptingImplementation> { }
    
    [Serializable]
    public class OptionalApiCompatibilityLevel : OptionalValue<ApiCompatibilityLevel> { }

    [Serializable]
    public class OptionalAndroidSdkVersions : OptionalValue<AndroidSdkVersions> { }

    [Serializable]
    public class OptionalAndroidArchitecture : OptionalValue<AndroidArchitecture> { }

    [Serializable]
    public class OptionalBuildOptions : OptionalValue<BuildOptions> { }
    
    [Serializable]
    public class OptionalGraphicsApiSelection : OptionalValue<GraphicsDeviceType> { }


    [CustomPropertyDrawer(typeof(OptionalString))]
    [CustomPropertyDrawer(typeof(OptionalBuildTarget))]
    [CustomPropertyDrawer(typeof(OptionalScriptingImplementation))]
    [CustomPropertyDrawer(typeof(OptionalAndroidSdkVersions))]
    [CustomPropertyDrawer(typeof(OptionalAndroidArchitecture))]
    [CustomPropertyDrawer(typeof(OptionalBuildOptions))]
    [CustomPropertyDrawer(typeof(OptionalGraphicsApiSelection))]
    public class OptionalValueDrawer : PropertyDrawer {
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label) {
            return 20;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label) {
            var enabled = property.FindPropertyRelative("enabled");
            var value = property.FindPropertyRelative("value");

            EditorGUI.BeginProperty(position, label, property);
            position = EditorGUI.PrefixLabel(position, GUIUtility.GetControlID(FocusType.Passive), label);

            var enabledRect = new Rect(position.x, position.y, 20, position.height);
            var valueRect = new Rect(position.x + 20, position.y, position.width - 20, position.height);
            EditorGUI.PropertyField(enabledRect, enabled, GUIContent.none);
            if(enabled.boolValue) {
                EditorGUI.PropertyField(valueRect, value, GUIContent.none);
            } else {
                EditorGUI.LabelField(valueRect, "(disabled)", EditorStyles.centeredGreyMiniLabel);
            }

            EditorGUI.EndProperty();
        }
    }
}