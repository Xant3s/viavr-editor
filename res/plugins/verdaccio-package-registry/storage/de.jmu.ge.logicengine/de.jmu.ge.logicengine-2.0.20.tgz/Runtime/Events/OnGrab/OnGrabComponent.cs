using de.jmu.ge.Logic.Runtime;
using de.jmu.ge.SpokeSceneImporter;
using UnityEngine;

public class OnGrabComponent : MonoBehaviour {
    public string uuid;
    public OnGrabEvent onGrabEvent; 
}