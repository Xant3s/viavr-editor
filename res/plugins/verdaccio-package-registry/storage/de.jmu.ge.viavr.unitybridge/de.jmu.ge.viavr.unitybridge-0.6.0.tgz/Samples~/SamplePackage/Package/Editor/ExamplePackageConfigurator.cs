using UnityEngine;
using de.jmu.ge.viavr.UnityBridge.Core;

/// <summary>
/// Implements the PackageConfigurator. This allows our example package to be configured
/// without the Unity editor. In this example it ensures that a GameObject with a
/// MathTest component has to exist in every scene.
/// </summary>
public class ExamplePackageConfigurator: PackageConfigurator {
    public override void Init() {
        Debug.Log("Init");
    }
    
    public override void OnConfigureScene() {
        Debug.Log("OnConfigureScene");
        new GameObject().AddComponent<MathTest>();
    }
    
    public override void OnPostConfiguration() {
        Debug.Log("OnPostConfiguration");
    }
}