using System.Linq;
using UnityEditor;

namespace de.jmu.ge.BuildUtils.Support {
    public static class SceneUtils {
        public static string[] GetEnabledScenes() =>
        (
            from scene in EditorBuildSettings.scenes
            where scene.enabled
            where !string.IsNullOrEmpty(scene.path)
            select scene.path
        ).ToArray();
    }
}