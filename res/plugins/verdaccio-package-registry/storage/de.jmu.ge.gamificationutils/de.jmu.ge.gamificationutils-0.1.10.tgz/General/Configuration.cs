using System;

namespace de.jmu.ge.Gamification.General {
    [Serializable]
    public class Configuration {
        public UiLabel[] labels;
    }

    [Serializable]
    public class UiLabel {
        public string name;
        public string fontSize;
        public string fontColor;
        public string position;
    }
}
