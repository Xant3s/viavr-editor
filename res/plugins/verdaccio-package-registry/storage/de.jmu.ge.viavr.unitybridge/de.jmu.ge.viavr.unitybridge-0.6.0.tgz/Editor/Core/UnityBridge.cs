using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;

namespace de.jmu.ge.viavr.UnityBridge.Core {
    public static class UnityBridge {
        public static void ExecuteAll() {
            Init();
            SetupScene();
            OnConfigureScene();
            OnConfigureLogic();
            OnConfigureUI();
            OnPostConfiguration();
        }
        
        public static void Init() => CallMethods(nameof(PackageConfigurator.Init));

        public static void SetupScene() => CallMethodsPerScene(nameof(PackageConfigurator.SetupScene));

        public static void OnConfigureScene() => CallMethodsPerScene(nameof(PackageConfigurator.OnConfigureScene));

        public static void OnConfigureLogic() => CallMethodsPerScene(nameof(PackageConfigurator.OnConfigureLogic));

        public static void OnConfigureUI() => CallMethodsPerScene(nameof(PackageConfigurator.OnConfigureUI));

        public static void OnPostConfiguration() => CallMethods(nameof(PackageConfigurator.OnPostConfiguration));

        private static void CallMethodsPerScene(string methodName) {
            string[] searchInFolders = {"Assets"};
            var guids = AssetDatabase.FindAssets("t:Scene", searchInFolders);
            foreach(var guid in guids) {
                var assetPath = AssetDatabase.GUIDToAssetPath(guid);
                EditorSceneManager.OpenScene(assetPath);
                CallMethods(methodName);
                EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
            }
        }
        
        private static void CallMethods(string methodName) {
            AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(assembly => assembly.GetTypes())
                .Where(t => t.IsSubclassOf(typeof(PackageConfigurator)))
                .ToList()
                .ForEach(subclass => {
                    var instance = Activator.CreateInstance(subclass);
                    subclass.GetMethod(methodName)?.Invoke(instance, null);
                });
        }
    }
}