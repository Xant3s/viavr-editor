﻿using System;
using UnityEngine;

public class Billboard: MonoBehaviour {
    public new Camera camera;
    public bool invert;
    private bool cameraExists;


    private void Awake() {
        if(!camera) camera = Camera.main;
        cameraExists = camera != null;
    }

    private void Update() {
        if(cameraExists) {
            transform.LookAt(camera.transform.position, Vector3.up);
            if(invert) transform.Rotate(0, 180, 0);
        }
    }
}
