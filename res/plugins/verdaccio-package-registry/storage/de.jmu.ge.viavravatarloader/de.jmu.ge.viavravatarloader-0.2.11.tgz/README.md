# viavr-avatar-loader



## Avatar Loader Package for VIA-VR Editor

Automatically spawn avatars to placeholders which have specific UUID values in the scene. It uses Avatar Loader package from Reality Stack.