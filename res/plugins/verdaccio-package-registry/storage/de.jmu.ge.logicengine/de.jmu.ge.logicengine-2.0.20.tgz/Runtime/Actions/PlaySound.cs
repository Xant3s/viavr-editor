﻿using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class PlaySound : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            UniqueIdParameter id = (UniqueIdParameter)parameters.getParameterValueByName("gameObject");
            GameObject gameObject = Utils.FindGameObjectWithID(id);
            var audioData = gameObject.GetComponent<AudioSource>();
            audioData.Play();
        }
    }
}