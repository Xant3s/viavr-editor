using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public abstract class LogicEvent: MonoBehaviour
    {
        public new string name;
        [SerializeField] public ParameterList parameters;
        [SerializeField] public List<ActionSequenceComponent> actionSequence;
        [SerializeField] public GameObject eventGameObject;

        // This has to be called at some point. Needs to be defined by the actual Event classes that derive from this one
        public void Invoke() {
            if (actionSequence != null) {
                foreach (var sequenceComponent in actionSequence) {
                    sequenceComponent.Invoke(this);
                }
            }
        }

        public abstract void OnConfigureLogic();
    }
}
