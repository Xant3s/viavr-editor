using UnityEditor;

namespace de.jmu.ge.BuildUtils.Support {
    public static class TargetGroupHelper {
        public static BuildTargetGroup GetTargetGroup(this BuildTarget target) => target switch {
            BuildTarget.StandaloneOSX       => BuildTargetGroup.Standalone,
            BuildTarget.StandaloneWindows   => BuildTargetGroup.Standalone,
            BuildTarget.StandaloneWindows64 => BuildTargetGroup.Standalone,
            BuildTarget.StandaloneLinux64   => BuildTargetGroup.Standalone,
            BuildTarget.iOS                 => BuildTargetGroup.iOS,
            BuildTarget.tvOS                => BuildTargetGroup.iOS,
            BuildTarget.Android             => BuildTargetGroup.Android,
            BuildTarget.WebGL               => BuildTargetGroup.WebGL,
            BuildTarget.WSAPlayer           => BuildTargetGroup.WSA,
            BuildTarget.PS4                 => BuildTargetGroup.PS4,
            BuildTarget.XboxOne             => BuildTargetGroup.XboxOne,
            BuildTarget.Switch              => BuildTargetGroup.Switch,
            BuildTarget.Lumin               => BuildTargetGroup.Lumin,
            BuildTarget.Stadia              => BuildTargetGroup.Stadia,
            _                               => BuildTargetGroup.Unknown
        };

        public static string GetBuildArtefactExtension(this BuildTarget target) => target switch {
            BuildTarget.Android => ".apk",
            BuildTarget.StandaloneWindows => ".exe",
            BuildTarget.StandaloneWindows64 => ".exe",
            _ => ""
        };
    }
}