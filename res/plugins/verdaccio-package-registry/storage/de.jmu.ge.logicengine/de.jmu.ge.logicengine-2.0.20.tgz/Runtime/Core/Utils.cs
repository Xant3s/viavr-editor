using System.Linq;
using de.jmu.ge.SpokeSceneImporter;
using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class Utils
    {
        public static GameObject FindGameObjectWithID(UniqueIdParameter id)
        {
            foreach (var uuid in Object.FindObjectsOfType<Uuid>().Where(uuid => uuid.serializedUuid.Equals(id.GetValue())))
            {
                return uuid.gameObject;
            }
            return null;
        }

        public static GameObject FindGameObjectWithID(string id)
        {
            foreach (var uuid in Object.FindObjectsOfType<Uuid>().Where(uuid => uuid.serializedUuid.Equals(id)))
            {
                return uuid.gameObject;
            }
            return null;
        }
    }
}