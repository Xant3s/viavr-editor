using System;
using de.jmu.ge.Logic.Editor;
using UnityEngine;

public class ControlUiTest : MonoBehaviour {
    public GameState task;
    public GameState date;
    public GameState health;
    public GameState enemy;

    private void Update() {
        // Task example
        if(Input.GetKeyDown(KeyCode.I)) {
            string taskValue = task.Value;
            string substr = taskValue.Substring(taskValue.Length - 1);
            if(substr.Equals("D")) {
                taskValue = taskValue.Remove(task.Value.Length - 1);
            }
            else {
                taskValue += "D";
            }

            task.Value = taskValue;
        }

        // Date example
        if(Input.GetKeyDown(KeyCode.J)) {
            date.Value = DateTime.Now.ToString("h:mm:ss");
        }

        // Health example
        if(Input.GetKeyDown(KeyCode.K)) {
            health.Value = (int.Parse(health.Value) + 1).ToString();
        }

        //Enemies example
        if(Input.GetKeyDown(KeyCode.L)) {
            enemy.Value = (int.Parse(enemy.Value) + 1).ToString();
        }
    }
}