using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using de.jmu.ge.BuildUtils.Support;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine.Events;


namespace de.jmu.ge.BuildUtils.Configuration {
    [CreateAssetMenu(fileName = "Build Configuration", menuName = "Build Utils/Build Configuration")]
    public class BuildConfiguration : ScriptableObject {
        [Header("Build")] 
        public OptionalBuildOptions buildOptions = new OptionalBuildOptions();

        [Header("Build Output")] 
        [Tooltip("This path will be appended to the default build path saved in the Build Utils Settings")]
        public OptionalString buildOutputPath = new OptionalString();
        public OptionalString buildName = new OptionalString();

        [Header("Build Platform")] 
        public OptionalBuildTarget buildTarget = new OptionalBuildTarget();
        public OptionalScriptingImplementation scriptingBackend = new OptionalScriptingImplementation();
        public OptionalApiCompatibilityLevel apiCompatibilityLevel = new OptionalApiCompatibilityLevel();

        [Header("Backend APIs")]
        public OptionalGraphicsApiSelection graphicsApi = new OptionalGraphicsApiSelection();

        [Header("Android")] 
        public OptionalAndroidSdkVersions minimalSDKVersion = new OptionalAndroidSdkVersions();
        public OptionalAndroidSdkVersions targetSDKVersion = new OptionalAndroidSdkVersions();
        public OptionalAndroidArchitecture targetArchitecture = new OptionalAndroidArchitecture();

        [Header("XR")]
        [Tooltip("Insert the filename of the XR plugin which is located in the folder that is defined in the build settings object")]
        public OptionalString xrLoader = new OptionalString();
        
        [Header("Build Commands")] 
        [TextArea(5, 10)] public string beforeBuildCommands;
        [TextArea(5, 10)] public string afterBuildCommands;

        [Header("Custom Dependencies")]
        public OptionalString customDependencies = new OptionalString();
        [HideInInspector]
        [SerializeField]
        private AddRequest dependencyAddRequest;


        public virtual void ApplyConfiguration() {
            ConditionalSet(buildTarget, "BuildTarget", value => EditorUserBuildSettings.SwitchActiveBuildTarget(value.GetTargetGroup(), value));
            ConditionalSet(scriptingBackend, "ScriptingBackend", value => PlayerSettings.SetScriptingBackend(EditorUserBuildSettings.selectedBuildTargetGroup, value));
            ConditionalSet(minimalSDKVersion, nameof(PlayerSettings.Android.minSdkVersion), value => PlayerSettings.Android.minSdkVersion = value);
            ConditionalSet(targetSDKVersion, nameof(PlayerSettings.Android.targetSdkVersion), value => PlayerSettings.Android.targetSdkVersion = value);
            UnityEditor.Compilation.CompilationPipeline.RequestScriptCompilation();
            ConditionalSet(targetArchitecture, nameof(PlayerSettings.Android.targetArchitectures), value => PlayerSettings.Android.targetArchitectures = value);
            ConditionalSet(apiCompatibilityLevel, "ApiCompatibilityLevel", value => PlayerSettings.SetApiCompatibilityLevel(EditorUserBuildSettings.selectedBuildTargetGroup, value));
            
            var outputDirectory = Settings.Current.RootedDefaultBuildPath;
            if(buildOutputPath.enabled) {
                outputDirectory = Path.IsPathRooted(buildOutputPath)
                    ? buildOutputPath
                    : Path.Combine(outputDirectory, buildOutputPath);
            }

            var buildFileName = (buildName.enabled ? buildName : Settings.Current.BuildName)
                                + EditorUserBuildSettings.activeBuildTarget.GetBuildArtefactExtension();
            var fullOutputPath = Path.Combine(outputDirectory, buildFileName);

            EditorUserBuildSettings.SetBuildLocation(EditorUserBuildSettings.activeBuildTarget, fullOutputPath);
            // BuildLogger.Log($"BuildLocation set to {fullOutputPath}", nameof(BuildConfiguration));

            ConditionalSet(graphicsApi,
                "GraphicsAPI",
                value =>
                {
                    PlayerSettings.SetUseDefaultGraphicsAPIs(EditorUserBuildSettings.activeBuildTarget, false); 
                    var possibleAPIs = PlayerSettings.GetGraphicsAPIs(EditorUserBuildSettings.activeBuildTarget).Prepend(value);
                    PlayerSettings.SetGraphicsAPIs(EditorUserBuildSettings.activeBuildTarget, possibleAPIs.ToArray());
                });

            ConditionalSet(customDependencies,
                "Custom dependencies",
                value =>
                {
                    dependencyAddRequest = Client.Add(value);
                    EditorApplication.update += HandleAddRequest;
                });
        }
        
        public void OnBeforeBuild() {
            ConditionalSet(xrLoader,
                "XRLoader",
                value =>
                    XRUtils.SetXRLoader(EditorUserBuildSettings.selectedBuildTargetGroup, xrLoader, Settings.Current.xrLoaderSearchPath));
        }

        private void HandleAddRequest()
        {
            if (!dependencyAddRequest.IsCompleted) return;
            
            if (dependencyAddRequest.Status == StatusCode.Success)
                Debug.Log("Installed: " + dependencyAddRequest.Result.packageId);
            else if (dependencyAddRequest.Status >= StatusCode.Failure)
                Debug.Log(dependencyAddRequest.Error.message);

            EditorApplication.update -= HandleAddRequest;
        }

        private static bool ConditionalSet<T>(OptionalValue<T> value, string label, Action<T> setter) {
            if(!value.enabled) {
                return false;
            }

            setter(value.value);
            // BuildLogger.Log($"{label} set to {value.value.ToString()}", nameof(BuildConfiguration));
            return true;
        }

        public static List<BuildConfiguration> GetAvailableConfigurations() {
            return AssetDatabase.FindAssets($"t:BuildConfiguration")
                                .Select(guid => AssetDatabase.LoadAssetAtPath<BuildConfiguration>(AssetDatabase.GUIDToAssetPath(guid)))
                                .ToList();
        }
    }
}