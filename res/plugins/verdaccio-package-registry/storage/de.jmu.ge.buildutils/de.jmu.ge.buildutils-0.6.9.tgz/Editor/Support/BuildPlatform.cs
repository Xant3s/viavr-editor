namespace de.jmu.ge.BuildUtils.Support {
    internal enum BuildPlatform {
        Android,
        Linux,
        Mac,
        Windows
    }
}