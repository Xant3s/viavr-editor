﻿using GamesEngineering.LogicEngine.Core;
using UnityEngine;

public class MousePickConditionSwitch : MonoBehaviour {
    private MeshRenderer meshRenderer;

    private void Start() {
        meshRenderer = gameObject.GetComponent<MeshRenderer>();
    }

    void Update() {
        if(!Input.GetMouseButtonDown(0))
            return;

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if(!Physics.Raycast(ray, out RaycastHit hit)) return;
        if(hit.transform == transform) {
            meshRenderer.material.SetColor("_Color", Color.green);
            GetComponent<ConditionSwitch>().SetTrue();
        }
    }
}