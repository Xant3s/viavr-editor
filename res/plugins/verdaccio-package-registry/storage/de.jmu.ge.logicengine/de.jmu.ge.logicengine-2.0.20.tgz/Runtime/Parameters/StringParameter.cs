﻿using System;

namespace Parameters
{
    [Serializable]
    public class StringParameter : Parameter
    {

        public StringParameter(string name, string value)
        {
            Name = name;
            parameterType = ParameterType.TypeString;
            StringValue = value;
        }
    }
}