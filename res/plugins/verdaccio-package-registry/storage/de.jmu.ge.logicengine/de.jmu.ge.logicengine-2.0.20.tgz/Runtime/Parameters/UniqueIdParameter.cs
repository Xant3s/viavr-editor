﻿using System.Collections.Generic;
using UnityEngine;

namespace Parameters
{
    public class UniqueIdParameter : Parameter
    {
        public static Dictionary<UniqueIdParameter, GameObject> dict = new Dictionary<UniqueIdParameter, GameObject>();

        public UniqueIdParameter(string uniqueID)
        {
            Name = "uuid";
            parameterType = ParameterType.TypeString;
            StringValue = uniqueID;
        }
    }
}