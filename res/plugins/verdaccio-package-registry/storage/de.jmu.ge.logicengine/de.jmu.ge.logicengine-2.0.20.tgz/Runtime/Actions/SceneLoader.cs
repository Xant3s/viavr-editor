using UnityEngine.SceneManagement;

namespace de.jmu.ge.Logic.Runtime {
    public class SceneLoader : Action {
        private Scene currentScene;

        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            currentScene = SceneManager.GetActiveScene();
            var nextSceneIndex = currentScene.buildIndex + 1;
            SceneManager.LoadScene(nextSceneIndex, LoadSceneMode.Single);
        }
    }
}