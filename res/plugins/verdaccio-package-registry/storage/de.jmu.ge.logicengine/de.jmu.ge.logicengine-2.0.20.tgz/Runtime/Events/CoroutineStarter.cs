using UnityEngine;


namespace de.jmu.ge.Logic.Runtime
{
    // Used to start Coroutines from events since they are ScriptableObjects
    class CoroutineStarter : MonoBehaviour { }
}