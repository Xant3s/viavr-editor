
using System;

namespace de.jmu.ge.Logic.Runtime
{
    public class NumberVariable : Variable
    {
        public void Init(string name, float value)
        {
            Name = name;
            variableType = VariableType.TypeNumber;
            NumberValue = value;
        }

        protected override bool handleComparisonInternal(string comparisonOperator, string comparisonValue)
        {
            float result;
            if (float.TryParse(comparisonValue, out result))
            {
                switch (comparisonOperator)
                {
                    case "=":
                        return NumberValue.Equals(result);
                    case "!=":
                        return !NumberValue.Equals(result);
                    case "<":
                        return NumberValue < result;
                    case "<=":
                        return NumberValue <= result;
                    case ">":
                        return NumberValue > result;
                    case ">=":
                        return NumberValue >= result;
                    default:
                        throw new ArgumentException("Unknown comparisonOperator", comparisonOperator);
                }
            }
            else
            {
                throw new ArgumentException("Compared value has the wrong type", comparisonValue);
            }
        }

    }
}