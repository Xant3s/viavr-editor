﻿using System;
using System.Collections.Generic;
using Articy.Unity;
using Articy.Unity.Interfaces;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace de.jmu.ge.viavr.dialogs.runtime {
    [RequireComponent(typeof(ArticyFlowPlayer))]
    public class Dialog: MonoBehaviour, IArticyFlowPlayerCallbacks {
        public string dialogId;
        public string avatarName;
        [SerializeField] private TMP_Text[] avatarNameTexts;
        [SerializeField] private TMP_Text contentText;
        [SerializeField] private Button[] buttons;
        [SerializeField] private GameObject dialogPanel;
        private ArticyFlowPlayer articyFlowPlayer;


        private void Awake() {
            articyFlowPlayer = GetComponent<ArticyFlowPlayer>();
        }

        private void Start() {
            var id = Convert.ToUInt64(dialogId, 16);
            articyFlowPlayer.StartOn = ArticyDatabase.GetObject(id);
            foreach(var tmpText in avatarNameTexts) {
                tmpText.text = avatarName;
            }
        }

        public void OnFlowPlayerPaused(IFlowObject currentNode) {
            if(currentNode != null) {
                var currentText = string.Empty;
                if(currentNode is IObjectWithText objWithText) {
                    currentText = objWithText.Text;
                    contentText.text = objWithText.Text;
                }
                if(currentNode is IObjectWithSpeaker objSpeaker) {
                    var speakerDisplayName = objSpeaker.Speaker as IObjectWithDisplayName;
                    var actor = speakerDisplayName?.DisplayName ?? string.Empty;
                    foreach(var tmpText in avatarNameTexts) {
                        tmpText.text = actor;
                    }
                }
                
                // Skip dialog fragment if it has no text and only one branch
                var hasExactlyOneBranch = articyFlowPlayer.AvailableBranches.Count == 1;
                if(string.IsNullOrWhiteSpace(currentText) && hasExactlyOneBranch) {
                    articyFlowPlayer.Play(articyFlowPlayer.AvailableBranches[0]);
                }
            }
            else {
                dialogPanel.SetActive(false);
            }
        }

        public void OnBranchesUpdated(IList<Branch> currentBranches) {
            for(var i = 0; i < buttons.Length; i++) {
                var correspondingBranchExists = currentBranches.Count > i;
                buttons[i].gameObject.SetActive(correspondingBranchExists);
                buttons[i].onClick.RemoveAllListeners();
                if(!correspondingBranchExists) continue;
                var branchText = string.Empty;
                if(currentBranches[i].Target is IObjectWithMenuText target) {
                    branchText = target.MenuText;
                }
                if(string.IsNullOrWhiteSpace(branchText)) {
                    var hasNext = currentBranches[i].Target is IObjectWithText;
                    branchText = hasNext ? "Continue" : "End dialog";
                }
                buttons[i].GetComponentInChildren<TMP_Text>().text = branchText;
                var i1 = i;
                buttons[i].onClick.AddListener(() => articyFlowPlayer.Play(currentBranches[i1]));
            }
        }
    }
}