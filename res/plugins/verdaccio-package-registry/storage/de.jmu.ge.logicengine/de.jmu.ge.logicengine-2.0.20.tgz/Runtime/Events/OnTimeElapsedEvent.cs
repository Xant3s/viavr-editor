﻿using System.Collections;
using System.Linq;
using UnityEngine;


namespace de.jmu.ge.Logic.Runtime
{
    public class OnTimeElapsedEvent : LogicEvent
    {
        private int timeInSeconds;
        CoroutineStarter coroutineStarter = new CoroutineStarter();

        public override void OnConfigureLogic() { }

        protected void Awake()
        {
            timeInSeconds = (int)parameters.getParameterValueByName("time");
            coroutineStarter.StartCoroutine(Countdown(timeInSeconds));
        }

        IEnumerator Countdown(int seconds)
        {
            int counter = seconds;
            while (counter > 0)
            {
                yield return new WaitForSeconds(1);
                counter--;
            }
            Invoke();
        }
    }
}