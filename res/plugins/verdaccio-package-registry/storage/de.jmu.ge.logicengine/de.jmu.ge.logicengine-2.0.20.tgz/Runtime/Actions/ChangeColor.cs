using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime {
    public class ChangeColor : Action {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            UniqueIdParameter id = (UniqueIdParameter)parameters.getParameterValueByName("gameObject");
            GameObject gameObject = Utils.FindGameObjectWithID(id);

            var myMat = gameObject.GetComponent<MeshRenderer>().material;
            myMat.SetColor("_Color", Color.green);
            myMat.SetColor("_EmissionColor", Color.green);
        }
    }
}