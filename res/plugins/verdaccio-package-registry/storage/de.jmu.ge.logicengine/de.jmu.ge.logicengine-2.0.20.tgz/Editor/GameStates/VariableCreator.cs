﻿using System.Collections.Generic;
using de.jmu.ge.Logic.Runtime;
using JetBrains.Annotations;
using UnityEditor;
using UnityEngine;

namespace de.jmu.ge.Logic.Editor
{
    public static class VariableCreator
    {
        private static string path;
        public static List<Variable> variables;

        public static void CreateVariables(List<Variable> existingVariables, [NotNull] IEnumerable<VariableJSON> variables, string creationPath)
        {
            VariableCreator.variables = existingVariables;
            path = creationPath;
            foreach (var variable in variables)
            {
                if (CheckIfVariableExists(variable)) continue;
                CreateVariable(variable);
            }
        }

        private static bool CheckIfVariableExists(VariableJSON variable)
        {
            foreach (var v in variables)
            {
                if (v.Name.Equals(variable.name))
                {
                    return true;
                }
            }
            return false;
        }

        private static void CreateVariable(VariableJSON state)
        {
            Variable newVariable = null;

            switch (state.type)
            {
                case "string":
                    newVariable = ScriptableObject.CreateInstance<StringVariable>();
                    ((StringVariable) newVariable).Init(state.name, state.value);
                    break;
                case "boolean":
                    newVariable = ScriptableObject.CreateInstance<BooleanVariable>();
                    ((BooleanVariable) newVariable).Init(state.name, bool.Parse(state.value));
                    break;
                case "number":
                    newVariable = ScriptableObject.CreateInstance<NumberVariable>();
                    ((NumberVariable) newVariable).Init(state.name, float.Parse(state.value));
                    break;
            }

            var variablePath = path + newVariable.Name + ".asset";
            AssetDatabase.CreateAsset(newVariable, variablePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            // Ensures that no variable will have a copy
            variables.Add(newVariable);
        }
    }
}