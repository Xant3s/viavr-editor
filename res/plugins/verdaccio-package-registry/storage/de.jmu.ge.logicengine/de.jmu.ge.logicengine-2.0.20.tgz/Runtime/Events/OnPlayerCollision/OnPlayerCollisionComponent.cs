using System.Linq;
using de.jmu.ge.Logic.Runtime;
using de.jmu.ge.SpokeSceneImporter;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class OnPlayerCollisionComponent : MonoBehaviour
{
    public string uuid;
    public string checkTag;
    public OnPlayerCollisionEvent onPlayerCollisionEvent;

    private void Start()
    {
        GetComponent<Rigidbody>().useGravity = false;
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        InvokeEvent(hit.collider.gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        InvokeEvent(collision.collider.gameObject);
    }

    private void InvokeEvent(GameObject go)
    {
        if (!string.IsNullOrEmpty(uuid)) {
            var uuid = go.GetComponentInParent<Uuid>();
            if (uuid && uuid.serializedUuid.Equals(uuid))
            {
                onPlayerCollisionEvent.eventGameObject = go;
                onPlayerCollisionEvent.Invoke();
            }
        } 
        else if (!string.IsNullOrEmpty(checkTag)) {
            var tags = go.GetComponentInParent<Tags>();
            if (tags && tags.tags.Contains(checkTag))
            {
                onPlayerCollisionEvent.eventGameObject = go;
                onPlayerCollisionEvent.Invoke();
            }
        }
    }
}