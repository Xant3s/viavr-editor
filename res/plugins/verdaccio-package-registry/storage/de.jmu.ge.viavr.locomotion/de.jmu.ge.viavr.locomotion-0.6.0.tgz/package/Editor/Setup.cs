﻿using de.jmu.ge.viavr.UnityBridge.Core;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

namespace Locomotion {
    public class Setup : PackageConfigurator {
        [MenuItem("Tools/Test Locomotion Setup")]
        public static void Test() {
            SpawnPlayer();
            SetupTeleportTargets();
        }
        
        public override void OnConfigureScene() {
            SpawnPlayer();
            SetupTeleportTargets();
        }

        private static void SpawnPlayer() {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Packages/de.jmu.ge.viavr.locomotion/Prefabs/XR Interaction Setup.prefab");
            var spawnPoint = GameObject.Find("Spawn Point");
            if(spawnPoint) {
                Object.Instantiate(prefab, spawnPoint.transform);
            }
            else {
                Object.Instantiate(prefab);
            }
        }

        private static void SetupTeleportTargets() {
            var tags = Object.FindObjectsOfType<de.jmu.ge.SpokeSceneImporter.Tags>();
            var teleportAnchorPrefab = AssetDatabase.LoadAssetAtPath<GameObject>("Packages/de.jmu.ge.viavr.locomotion/Prefabs/Snapping Teleport Anchor.prefab");
            foreach(var currentObject in tags) {
                foreach(var currentTag in currentObject.tags) {
                    switch (currentTag) {
                        case "Floor":
                            var teleportationArea = currentObject.gameObject.AddComponent<TeleportationArea>();
                            var collider = currentObject.gameObject.GetComponentInChildren<Collider>();
                            if(!collider) {
                                collider = teleportationArea.gameObject.AddComponent<BoxCollider>();
                            }
                            else {
                                collider.isTrigger = false;
                            }
                            teleportationArea.colliders.Add(collider);
                            teleportationArea.interactionLayers = -1;   // Everything.
                            teleportationArea.matchDirectionalInput = true;
                            break;
                        case "Teleport Anchor":
                            Object.Instantiate(teleportAnchorPrefab, currentObject.transform);
                            break;
                        case "Grab":
                            if (!currentObject.gameObject.GetComponent<XRGrabInteractable>()) {
                                var interactable = currentObject.gameObject.AddComponent<XRGrabInteractable>();
                                interactable.useDynamicAttach = true;
                            }
                            
                            var grabCollider = currentObject.gameObject.GetComponent<Collider>();
                            if (grabCollider == null) {
                                var meshCollider = currentObject.gameObject.AddComponent<MeshCollider>();
                                meshCollider.convex = true;
                            } else if (grabCollider is MeshCollider existingMeshCollider) {
                                existingMeshCollider.convex = true;
                            }
                            
                            var rigidbody = currentObject.gameObject.GetComponent<Rigidbody>();
                            if (rigidbody == null) {
                                rigidbody = currentObject.gameObject.AddComponent<Rigidbody>();
                            }
                            rigidbody.isKinematic = false;
                            break;
                    }
                }
            }
        }
    }
}