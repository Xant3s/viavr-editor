using UnityEngine;

public class VRCanvas : MonoBehaviour {
    [SerializeField] public float distance = 1.5f;
    [SerializeField] public float speed = 10f;
    
    private Transform cameraTransform;


    void Start() {
        cameraTransform = Camera.main.transform;
        transform.position = CalculatePosition();
    }

    void Update() {
        MoveInFrontOfCamera();
        RotateTowardsCamera();
    }

    //TODO implement Coroutine with slerp to move the canvas

    private void MoveInFrontOfCamera() {
        Vector3 pos = CalculatePosition();
        float distance = Vector3.Distance(transform.position, pos);
        transform.position = Vector3.MoveTowards(transform.position, pos, speed * distance * Time.deltaTime);
    }

    private void RotateTowardsCamera() {
        transform.rotation = Quaternion.LookRotation(transform.position - cameraTransform.position);
    }

    private Vector3 CalculatePosition() {
        return cameraTransform.position + cameraTransform.forward * distance;
    }
}

