using Parameters;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class ChangeVariableValue : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            Parameter variableName = (Parameter)parameters.getParameterValueByName("variable");
            Parameter newValue = (Parameter)parameters.getParameterValueByName("newValue");
            var variable = Resources.Load<Variable>("Variables/" + variableName);

            if (variable.GetType() == typeof(BooleanVariable))
            {
                variable.BoolValue = newValue.BoolValue;
            }
            else if (variable.GetType() == typeof(NumberVariable))
            {
                variable.NumberValue = newValue.NumberValue;
            }
            else if (variable.GetType() == typeof(StringVariable))
            {
                variable.StringValue = newValue.StringValue;
            }
        }
    }
}