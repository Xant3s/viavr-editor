﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using de.jmu.ge.Logic.Runtime;
using de.jmu.ge.viavr.UnityBridge.Core;
using de.jmu.ge.viavr.UnityBridge.Utils;
using UnityEditor;
using UnityEngine;

namespace de.jmu.ge.Logic.Editor
{

    public class LogicEngineConfigurator : PackageConfigurator
    {
        private readonly ConfigurationProvider<Configuration> configProvider =
            new JsonLoader<Configuration>("Assets/Settings/BuildSettings.json");
        private const string variablesPath = "Assets/Resources/Variables/";
        private const string eventsPath = "Assets/Resources/Events/";

        public static GameObject logicEngineGO;

        public override void Init()
        {
        }

        public override void OnConfigureLogic()
        {
            logicEngineGO = new GameObject("LogicEngine");

            var configuration = configProvider.GetConfiguration();
            InitVariables(configuration);
            InitEvents(configuration);

            List<LogicEvent> logicEvents = FindAllExistingEvents();
            logicEvents.ForEach(e =>
            {
                e.OnConfigureLogic();
            });
        }

        private void InitVariables(Configuration configuration)
        {
            if (configuration.variables == null) return;
            if (!Directory.Exists(variablesPath)) Directory.CreateDirectory(variablesPath);
            VariableCreator.CreateVariables(FindAllExistingVariables(), configuration.variables, variablesPath);
        }

        private List<Variable> FindAllExistingVariables()
        {
            var folders = new[] { variablesPath };
            var findAssets = AssetDatabase.FindAssets("t: Variable", folders);

            return findAssets.Select(AssetDatabase.GUIDToAssetPath)
                .Select(AssetDatabase.LoadAssetAtPath<Variable>).ToList();
        }

        private void InitEvents(Configuration configuration)
        {
            if (configuration.events == null) return;
            if (!Directory.Exists(eventsPath)) Directory.CreateDirectory(eventsPath);
            List<LogicEvent> existingEvents = FindAllExistingEvents();
            EventCreator.CreateEvents(existingEvents, configuration.events, eventsPath);
        }

        private List<LogicEvent> FindAllExistingEvents()
        {
            return GameObject.FindObjectsOfType<LogicEvent>().ToList();
        }
    }
}