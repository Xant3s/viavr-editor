using de.jmu.ge.Logic.Runtime;
using de.jmu.ge.SpokeSceneImporter;
using UnityEngine;

public class OnCollisionComponent : MonoBehaviour {
    public string uuid;
    public OnCollisionEvent onCollisionEvent; 

    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.GetComponentInParent<Uuid>().serializedUuid.Equals(uuid)) {
            onCollisionEvent.Invoke();
        }
    }
}