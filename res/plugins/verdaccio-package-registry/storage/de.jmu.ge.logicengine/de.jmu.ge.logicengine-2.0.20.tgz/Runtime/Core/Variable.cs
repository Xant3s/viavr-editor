using System;
using UnityEngine;
using UnityEngine.Events;

namespace de.jmu.ge.Logic.Runtime
{
    [Serializable]
    public abstract class Variable : ScriptableObject
    {
        public enum VariableType
        {
            TypeNumber,
            TypeString,
            TypeBool
        }
        public UnityAction onValueChange;

        [SerializeField] private string _name;
        [SerializeField] public VariableType variableType;

        [SerializeField] private float _numberValue;
        [SerializeField] private string _stringValue;
        [SerializeField] private bool _boolValue;

        public string Name
        {
            get => _name;
            set
            {
                if (value != _name)
                {
                    _name = value;
                }
            }
        }

        public float NumberValue
        {
            get => _numberValue;
            set
            {
                if (_numberValue != value)
                {
                    _numberValue = value;
                    onValueChange?.Invoke();
                }
            }
        }
        public string StringValue
        {
            get => _stringValue;
            set
            {
                if (_stringValue != value)
                {
                    _stringValue = value;
                    onValueChange?.Invoke();
                }
            }
        }

        public bool BoolValue
        {
            get => _boolValue;
            set
            {
                if (_boolValue != value)
                {
                    _boolValue = value;
                    onValueChange?.Invoke();
                }
            }
        }

        public bool handleComparison(string comparisonOperator, string comparisonValue)
        {
            return handleComparisonInternal(comparisonOperator, comparisonValue);
        }

        public object GetValue()
        {
            switch (variableType)
            {
                case VariableType.TypeNumber:
                    return NumberValue;
                case VariableType.TypeString:
                    return StringValue;
                case VariableType.TypeBool:
                    return BoolValue;
                default:
                    return null;
            }
        }
        protected abstract bool handleComparisonInternal(string comparisonOperator, string comparisonValue);
    }
}
