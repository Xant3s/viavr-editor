using UnityEditor;
using de.jmu.ge.BuildUtils.Editor;
using de.jmu.ge.BuildUtils.Build;

namespace de.jmu.ge.BuildUtils {
    public static class BuildMenu {
        [MenuItem("Build/Build Configuration/Select Configuration...", priority = 1)]
        private static void ShowBuildConfigurationSelection() => BuildConfigurationSelectionWindow.Init();

        [MenuItem("Build/Build Configuration/Display Build Information", priority = 1)]
        private static void ShowBuildInformationCommand() => ManualBuildWindow.ShowBuildInformation();

        [MenuItem("Build/Build Configuration/Open Build Folder", priority = 1)]
        private static void OpenBuildFolderCommand() => EditorUtility.RevealInFinder(EditorUserBuildSettings.GetBuildLocation(EditorUserBuildSettings.activeBuildTarget));
        
        [MenuItem("Build/Build",  priority = 100)]
        public static void BuildCommand() => ManualBuild.Build(Settings.Current.localBuildOptions & ~BuildOptions.AutoRunPlayer);

        [MenuItem("Build/Build And Run", priority = 101)]
        public static void BuildAndRunCommend() => ManualBuild.Build(Settings.Current.localBuildOptions | BuildOptions.AutoRunPlayer);
        
        [MenuItem("Build/Reveal Build Utils Settings", priority = 301)]
        private static void ShowBuildSettings() => EditorGUIUtility.PingObject(AssetDatabase.LoadMainAssetAtPath(BuildManager.BuildSettingsPath));
    }
}