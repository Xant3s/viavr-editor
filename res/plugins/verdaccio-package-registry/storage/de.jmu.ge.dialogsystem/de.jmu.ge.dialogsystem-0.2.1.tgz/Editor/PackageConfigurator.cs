using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using de.jmu.ge.SpokeSceneImporter;
using de.jmu.ge.viavr.dialogs.runtime;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;
using UnityEngine.Assertions;

namespace de.jmu.ge.viavr.dialogs.editor {
    public class DialogConfigurator : UnityBridge.Core.PackageConfigurator {
        private const string dialogPrefabPath = "Packages/de.jmu.ge.dialogsystem/Prefabs/Dialog.prefab";
        private Vector3 dialogSpawnOffset = new Vector3(0, 1f, 0);

        
        [MenuItem("Tools/Test Spawn Dialogs")]
        public static void TestSpawnDialogs() {
            var instance = new DialogConfigurator();
            instance.OnConfigureScene();
        }

        public override void Init() {
            EnsureDirectory("Assets/Settings");
            EnsureDirectory("Assets/Resources");
            if(File.Exists("Assets/Settings/BuildSettings.json"))
                File.Copy("Assets/Settings/BuildSettings.json",
                    "Assets/Resources/BuildSettings.json", true);
        }

        public override void OnConfigureScene() {
            LoadDialogPrefab(out var dialogPrefab);
            LoadBuildSettings(out var buildSettings);
            List<AvatarData> avatars = buildSettings?["avatars"]?.ToObject<List<AvatarData>>();
            if(avatars == null || avatars.Count == 0) return;
            var allUuids = GameObject.FindObjectsOfType<Uuid>();
            
            // spawn dialog prefab for each avatar
            foreach(var avatar in avatars) {
                var avatarObj = allUuids.FirstOrDefault(id => string.Equals(avatar.sceneObject, id.serializedUuid, StringComparison.CurrentCultureIgnoreCase))?.gameObject;
                if(avatarObj == null) continue;
                var dialogObj = PrefabUtility.InstantiatePrefab(dialogPrefab) as GameObject;
                dialogObj.transform.SetParent(avatarObj.transform);
                dialogObj.transform.position = avatarObj.transform.position + dialogSpawnOffset;
                var dialog = dialogObj.GetComponent<Dialog>();
                dialog.avatarName = avatar.name;
                dialog.dialogId = avatar.dialogueId;
            }
        }

        private static void EnsureDirectory(string path) {
            if(!Directory.Exists(path)) Directory.CreateDirectory(path);
        }

        private static void LoadBuildSettings(out dynamic buildSettings) {
            var buildSettingsText = Resources.Load("BuildSettings").ToString();
            buildSettings = JsonConvert.DeserializeObject(buildSettingsText);
        }

        private static void LoadDialogPrefab(out GameObject prefab) {
            prefab = AssetDatabase.LoadAssetAtPath<GameObject>(dialogPrefabPath);
            Assert.AreNotEqual(prefab, null);
        }
    }
}
