
using System;

namespace de.jmu.ge.Logic.Runtime
{
    public class StringVariable : Variable
    {   
        public void Init(string name, string value) 
        {
            Name = name;
            variableType = VariableType.TypeString;
            StringValue = value;
        }

        protected override bool handleComparisonInternal(string comparisonOperator, string comparisonValue)
        {
            switch (comparisonOperator)
            {
                case "=":
                    return StringValue.Equals(comparisonValue);
                case "!=":
                    return !StringValue.Equals(comparisonValue);
                default:
                    throw new ArgumentException("Unknown comparisonOperator", comparisonOperator);
            }
        }

    }
}
