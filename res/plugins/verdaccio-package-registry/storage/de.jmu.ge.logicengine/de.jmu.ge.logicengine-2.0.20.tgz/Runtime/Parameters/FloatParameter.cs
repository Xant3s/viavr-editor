﻿using System;

namespace Parameters
{
    [Serializable]
    public class NumberParameter : Parameter
    {
        public NumberParameter(string name, float value)
        {
            Name = name;
            parameterType = ParameterType.TypeNumber;
            NumberValue = value;
        }
    }
}