namespace de.jmu.ge.viavr.UnityBridge.Core {
    public abstract class PackageConfigurator {
        /// <summary>
        /// Called once when the Unity project is created.
        /// Might be used to modify the project structure, e.g. to add a
        /// scriptable object asset file. Like Unity's Awake() methods, the order
        /// is not defined, but it is guaranteed that this method is called before
        /// the OnConfigureScene() methods.
        /// </summary>
        public virtual void Init(){}
        
        /// <summary>
        /// Called once for every scene in the Unity project. At the time of
        /// execution the scene is loaded. Use this method to import non-glTF objects from Spoke.
        /// All changes to the scene are saved after execution.
        /// </summary>
        public virtual void SetupScene(){}
        
        /// <summary>
        /// Called once for every scene in the Unity project. At the time of
        /// execution the scene is loaded. All changes to the scene are saved
        /// after execution.
        /// </summary>
        public virtual void OnConfigureScene(){}
        
        /// <summary>
        /// Called once for every scene in the Unity project. At the time of
        /// execution the scene is loaded. Use this method to add functionality of the logic engine 
        /// after all scenes are configured. All changes to the scene are saved after execution.
        /// </summary>
        public virtual void OnConfigureLogic(){}

        /// <summary>
        /// Called once for every scene in the Unity project. At the time of
        /// execution the scene is loaded. Use this method to add UI of the logic engine variables
        /// after all logic is configured. All changes to the scene are saved after execution.
        /// </summary>
        public virtual void OnConfigureUI(){}

        /// <summary>
        /// Called once when all previous configuration methods have been called.
        /// </summary>
        public virtual void OnPostConfiguration(){}
    }
}