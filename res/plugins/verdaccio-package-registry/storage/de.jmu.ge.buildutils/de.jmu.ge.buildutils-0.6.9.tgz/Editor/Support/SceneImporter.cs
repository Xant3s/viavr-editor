﻿using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace de.jmu.ge.BuildUtils {
    [Serializable]
    internal class SceneList {
        public string[] Scenes;
    }
    
    public static class SceneImporter {
        public static void AddScenesToBuildSettings() {
            var json = File.ReadAllText("Assets/Settings/Scenes.json");
            var sceneList = JsonUtility.FromJson<SceneList>(json);
            EditorBuildSettings.scenes = sceneList.Scenes.Select(sceneName => 
                    new EditorBuildSettingsScene($"Assets/Scenes/{sceneName}.unity", true)).ToArray();
        }
    }
}