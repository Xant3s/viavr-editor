﻿using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using PackageInfo = UnityEditor.PackageManager.PackageInfo;


namespace Samples.Gamification_Utils {
    public class SamplesEditor : EditorWindow {
        private const string sampleName = "Simple Gamification Sample";
        private static string version;
        private static string jsonPath;
        private string sourceFilePath;
        private string sourceMetaFilePath;
        private const string directoryPath = "Assets/Settings/de.jmu.ge.gamificationutils";
        private const string destinationFilePath = "Assets/Settings/de.jmu.ge.gamificationutils/Configuration.json";
        private const string destinationMetaFilePath = "Assets/Settings/de.jmu.ge.gamificationutils/Configuration.json.meta";

        private bool hideButtons;
        private readonly List<string> logList = new List<string>();


        [InitializeOnLoadMethod]
        static void Init() {
            // Ignores this script when entering the Playmode
            if(EditorApplication.isPlayingOrWillChangePlaymode)
                return;
            
            // Get the right package version to automatically set the right paths
            var packages = PackageInfo.GetAllRegisteredPackages();
            foreach(var package in packages) {
                if(package.name.Equals("de.jmu.ge.gamificationutils"))
                    version = package.version;
            }
            jsonPath = "Assets/Samples/Gamification Utils/" + version + "/Simple Example/SampleInitialized.json";
            
            // Creates and uses a JSON file to determine if Samples Editor should be called
            if(!File.Exists(jsonPath)) {
                File.WriteAllText(jsonPath, "false");
            }

            if(bool.Parse(File.ReadAllText(jsonPath))) {
                return;
            }
            File.WriteAllText(jsonPath, "true");
            
            // Init Samples Editor Window
            var window = GetWindow<SamplesEditor>();
            window.titleContent = new GUIContent("Samples Editor");
            window.minSize = new Vector2(400, 300);
            window.sourceFilePath = "Assets/Samples/Gamification Utils/" + version +
                                    "/Simple Example/Configuration.json";
            window.sourceMetaFilePath = "Assets/Samples/Gamification Utils/" + version +
                                    "/Simple Example/Configuration.json.meta";
        }

        private void OnGUI() {
            GUI.skin.label.wordWrap = true;
            GUILayout.Label($"Do you want to initialize the sample {sampleName}? It will create the Settings/de.jmu.ge.gamificationutils folder " +
                            $"(if not already present). And moves the Configuration.json file into it. " +
                            $"Note: This will overwrite any Configuration.json file that is already present!");
            GUILayout.Space(20);

            if(!hideButtons) {
                GUI.contentColor = Color.green;
                if(GUILayout.Button("Yes")) {
                    MoveConfigFileToSettings();
                    hideButtons = true;
                }
                
                GUI.contentColor = Color.red;
                if(GUILayout.Button("No")) {
                    Close();
                }
                GUILayout.FlexibleSpace();
            }

            GUI.contentColor = Color.yellow;
            GUILayout.BeginHorizontal();
            GUILayout.Label($"Log: ");
            GUILayout.Label($"{DisplayLog()}");
            GUILayout.EndHorizontal();

            if(hideButtons) {
                GUI.contentColor = Color.red;
                if (GUILayout.Button("Close")) {
                    Close();
                }
            }
            
            GUILayout.Space(20);
        }

        private void MoveConfigFileToSettings() {
            if(!Directory.Exists(directoryPath)) {
                Directory.CreateDirectory(directoryPath);
                logList.Add("Directory was successfully created!");
            }

            if(!File.Exists(sourceFilePath)) {
                logList.Add("No Configuration file found! Can't initialize sample!");
                return;
            }

            // Delete file at destination and use new config file
            if (File.Exists(destinationFilePath)) {
                File.Delete(destinationFilePath);
                logList.Add($"A configuration file was already present at {directoryPath}. Deleting file...");
            } 
            // Same for Meta file
            if (File.Exists(destinationMetaFilePath)) {
                File.Delete(destinationMetaFilePath);
                logList.Add($"A configuration meta file was already present at {directoryPath}. Deleting file...");
            }

            File.Move(sourceFilePath, destinationFilePath);
            logList.Add($"Configuration file was moved to {directoryPath} folder.");
            File.Move(sourceMetaFilePath, destinationMetaFilePath);
            logList.Add($"Configuration meta file was moved to {directoryPath} folder.");
            AssetDatabase.Refresh();
            logList.Add("Please Simulate Unity Bridge Call!");
        }

        private string DisplayLog() {
            var result = "";

            foreach (var log in logList) {
                result += log;
                result += "\n";
            }

            return result;
        }
    }
}
