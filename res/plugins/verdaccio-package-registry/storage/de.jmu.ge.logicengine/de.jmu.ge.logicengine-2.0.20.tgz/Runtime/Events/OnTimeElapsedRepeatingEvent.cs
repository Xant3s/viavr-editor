﻿using System.Collections;
using UnityEngine;


namespace de.jmu.ge.Logic.Runtime
{
    public class OnTimeElapsedRepeatingEvent : LogicEvent
    {
        CoroutineStarter coroutineStarter = new CoroutineStarter();
        private int timeInSeconds;

        public override void OnConfigureLogic() { }

        protected void Start()
        {
            timeInSeconds = (int)parameters.getParameterValueByName("time");
            coroutineStarter.StartCoroutine(Countdown(timeInSeconds));
        }

        IEnumerator Countdown(int seconds)
        {
            int counter = seconds;
            while (counter > 0)
            {
                yield return new WaitForSeconds(1);
                counter--;
            }
            Invoke();
            coroutineStarter.StartCoroutine(Countdown(timeInSeconds));
        }
    }
}