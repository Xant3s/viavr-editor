using System;

namespace de.jmu.ge.Logic.Runtime
{
    public interface Action
    {
        public abstract void Invoke(ParameterList parameters, LogicEvent logicEvent);
    }

}