using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using de.jmu.ge.BuildUtils.Support;
using de.jmu.ge.BuildUtils.Configuration;


namespace de.jmu.ge.BuildUtils {
    [CreateAssetMenu(fileName = "BuildSettings", menuName = "Build Utils/Settings")]
    public class Settings : ScriptableObject {
        [Header("Build")] 
        public string defaultBuildName;
        public string defaultBuildPath = "Build";
        
        [Header("Local Build")]
        public BuildOptions localBuildOptions = BuildOptions.None;
        
        [Header("XR Support")]
        [Tooltip("Directory, originating in the project root, in which xr loaders will be searched")]
        public string xrLoaderSearchPath = "Assets/XR/Loaders";

        [HideInInspector]
        [SerializeField]
        private BuildConfiguration activeBuildConfiguration;


        public BuildConfiguration ActiveBuildConfiguration {
            get => activeBuildConfiguration;
            set {
                activeBuildConfiguration = value;
                activeBuildConfiguration.ApplyConfiguration();
                EditorUtility.SetDirty(Current);
            }
        }

        public string BuildName => !NullOrEmpty(defaultBuildName) ? defaultBuildName : ProjectName;

        public static string ProjectName => Application.dataPath.Split('/')
                                                                .Reverse()
                                                                .Skip(1)
                                                                .FirstOrDefault();
        
        public string RootedDefaultBuildPath =>
            !NullOrEmpty(defaultBuildPath) && Path.IsPathRooted(defaultBuildPath)
                ? defaultBuildPath
                : FileSupport.GetAbsolutePathInProjectRoot(defaultBuildPath);
        
        public static Settings Current {
            get {
                var assets = AssetDatabase.FindAssets($"t:{nameof(Settings)}");
                if(assets.Length > 0) {
                    var path = AssetDatabase.GUIDToAssetPath(assets[0]);
                    return AssetDatabase.LoadAssetAtPath<Settings>(path);
                }

                var config = CreateInstance<Settings>();
                EnsureSettingsFolderExists();
                AssetDatabase.CreateAsset(config, "Assets/Settings/BuildSettings.asset");
                return config;
            }
        }

        private static void EnsureSettingsFolderExists() {
            var settingsFolder = Application.dataPath + "/Settings";
            if(!Directory.Exists(settingsFolder)) {
                Directory.CreateDirectory(settingsFolder);
            }
        }

        private static bool NullOrEmpty(string str) => str == null || str.Trim().Length == 0;
    }
}