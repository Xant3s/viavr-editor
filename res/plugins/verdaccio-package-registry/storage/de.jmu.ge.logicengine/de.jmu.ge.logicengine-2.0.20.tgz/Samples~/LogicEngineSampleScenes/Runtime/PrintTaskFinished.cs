﻿using UnityEngine;

public class PrintTaskFinished : MonoBehaviour {
    public void Print() => Debug.Log("Task finished");
}