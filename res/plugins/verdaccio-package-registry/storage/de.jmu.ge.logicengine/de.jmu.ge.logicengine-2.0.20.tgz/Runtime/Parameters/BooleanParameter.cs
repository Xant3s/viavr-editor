using System;

namespace Parameters {
    [Serializable]
    public class BooleanParameter: Parameter {
        public BooleanParameter(string name, bool value) {
            Name = name;
            parameterType = ParameterType.TypeBool;
            BoolValue = value;
        }
    }
}