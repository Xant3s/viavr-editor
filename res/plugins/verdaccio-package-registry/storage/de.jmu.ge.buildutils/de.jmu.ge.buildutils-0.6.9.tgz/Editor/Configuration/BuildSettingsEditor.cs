﻿using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine.UIElements;

namespace de.jmu.ge.BuildUtils {
    [CustomEditor(typeof(Settings))]
    public class BuildSettingsEditor : UnityEditor.Editor {
        public override VisualElement CreateInspectorGUI() {
            var buildSettings = (Settings) target;
            var root = new VisualElement();
            root.Add(new IMGUIContainer(base.OnInspectorGUI));
            root.Bind(new SerializedObject(buildSettings));
            return root;
        }
    }
}