
using System;
using System.Collections.Generic;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    [Serializable]
    public class ActionSequenceComponent
    {
        public enum ComponentType {
            Action,
            IfElse
        }

        // Properties have to be defined here, otherwise they cannot be saved in ScriptableObjects
        [SerializeField] public ComponentType componentType;

        // Action
        [SerializeField] public string name;
        [SerializeField] public ParameterList parameters;

        // IfElse 
        [SerializeField] public Variable variable;

        [SerializeField] public string comparisonOperator;
        [SerializeField] public string comparisonValue;
        [SerializeField] public List<ActionSequenceComponent> thenActionSequence;
        [SerializeField] public List<ActionSequenceComponent> elseActionSequence;
        public void Invoke(LogicEvent logicEvent) { 
            if (componentType == ComponentType.Action) {
                InvokeAction(logicEvent);
            } else if (componentType == ComponentType.IfElse) {
                InvokeIfElse(logicEvent);
            }
        }

        private void InvokeAction(LogicEvent logicEvent) {
            Type type = GetType(name);
            var action = Activator.CreateInstance(type);
            type.GetMethod("Invoke").Invoke(action, new object[]{parameters, logicEvent});
        }

        private void InvokeIfElse(LogicEvent logicEvent) {
            if (variable.handleComparison(comparisonOperator, comparisonValue))
            {
                foreach (var sequenceComponent in thenActionSequence)
                {
                    sequenceComponent.Invoke(logicEvent);
                }
            }
            else
            {
                foreach (var sequenceComponent in elseActionSequence)
                {
                    sequenceComponent.Invoke(logicEvent);
                }
            }
        }

        public static Type GetType(string typeName)
        {
            var type = Type.GetType(typeName);
            if (type != null) return type;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                type = a.GetType(typeName);
                if (type != null)
                    return type;
            }
            return null;
        }
    }
}