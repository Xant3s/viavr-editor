namespace de.jmu.ge.viavr.UnityBridge.Utils {
    public interface ConfigurationProvider<out T> {
        public T GetConfiguration();
        public bool HasConfiguration();
    }
}