using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    [Serializable]
    public class SampleAction : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            Debug.Log("SampleAction execute");
        }
    }
}
