using de.jmu.ge.BuildUtils.Configuration;
using UnityEditor;


namespace de.jmu.ge.BuildUtils.Editor {
    public class ManualBuildWindow {
        public static void ConfigureBuildEditor(BuildConfiguration configuration) {
            if(!DisplayConfigurationSwitchDialog(configuration.name)) {
                return;
            }

            Settings.Current.ActiveBuildConfiguration = configuration;
            ShowBuildInformation();

            // if(EditorUtility.DisplayDialog("Configuration Changed",
            //     "Would you like to load the default scenes for this configuration?", "OK", "Cancel")) {
            //     // SceneHelper.LoadScenesFromEditorBuildSettings(4);
            //     Debug.Log("Not implemented yet");
            // }
        }

        public static void ShowBuildInformation() {
            var information =
                $"Active Build Configuration: {Settings.Current.ActiveBuildConfiguration}\n" +
                $"{Settings.Current.ActiveBuildConfiguration}\n" +
                $"Target: {EditorUserBuildSettings.activeBuildTarget}\n" +
                $"Build Location: {EditorUserBuildSettings.GetBuildLocation(EditorUserBuildSettings.activeBuildTarget)}";

            EditorUtility.DisplayDialog("Build Configuration", information, "Close");
        }

        public static bool DisplayConfigurationSwitchDialog(string targetConfiguration) {
            return EditorUtility.DisplayDialog(
                $"Changing Build Configuration to {targetConfiguration}",
                $"Changing the build configuration will force a reimport of some assets and can take several minutes. Are you sure?\n\nPlease note that, a few moments after the first progress bar disappears, a second code reload might be triggered."
                ,
                "Continue", "Abort");
        }
    }
}