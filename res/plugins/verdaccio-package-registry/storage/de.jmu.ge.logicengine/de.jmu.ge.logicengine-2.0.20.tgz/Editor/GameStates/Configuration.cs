﻿using System;
using System.Collections.Generic;
using de.jmu.ge.Logic.Runtime;
using Parameters;
using UnityEditor;
using UnityEngine;
using Action = de.jmu.ge.Logic.Runtime.Action;

namespace de.jmu.ge.Logic.Editor
{
    [Serializable]
    public class Configuration
    {
        public VariableJSON[] variables;
        public LogicEventJSON[] events;
    }

    [Serializable]
    public class VariableJSON
    {
        public string name;
        public string type;
        public string value;
    }

    [Serializable]
    public class LogicEventJSON
    {
        public string name;
        public string id;
        public ParameterJSON[] parameters;
        public ActionSequenceComponentJSON[] actionSequence;

        public ParameterList ConvertParametersToList(ParameterJSON[] parameters)
        {
            ParameterList parameterList = new ParameterList();

            foreach (ParameterJSON parameter in parameters)
            {
                Parameter newParameter = null;
                switch (parameter.type)
                {
                    case "string":
                        newParameter = new StringParameter(parameter.name, parameter.value);
                        break;
                    case "number":
                        newParameter = new NumberParameter(parameter.name, float.Parse(parameter.value));
                        break;
                    case "boolean":
                        newParameter = new BooleanParameter(parameter.name, bool.Parse(parameter.value));
                        break;
                }
                parameterList.parameters.Add(newParameter);
            }

            return parameterList;
        }

        public List<ActionSequenceComponent> ConvertActionSequenceComponents(ActionSequenceComponentJSON[] actionSequenceComponents)
        {
            var actionSequence = new List<ActionSequenceComponent>();

            foreach (ActionSequenceComponentJSON actionSequenceComponent in actionSequenceComponents)
            {
                // Different ActionSequenceComponent types have to be saved to the same class since Unity does not support inheritance in serialization
                if (actionSequenceComponent.type == "action")
                {
                    actionSequence.Add(new ActionSequenceComponent
                    {
                        componentType = ActionSequenceComponent.ComponentType.Action,
                        name = actionSequenceComponent.name,
                        parameters = ConvertParametersToList(actionSequenceComponent.parameters)
                    });
                }
                else if (actionSequenceComponent.type == "ifElse")
                {
                    actionSequence.Add(new ActionSequenceComponent
                    {
                        componentType = ActionSequenceComponent.ComponentType.IfElse,
                        variable = VariableCreator.variables.Find(item => item.name == actionSequenceComponent.name),
                        comparisonOperator = actionSequenceComponent.comparisonOperator,
                        comparisonValue = actionSequenceComponent.comparison,
                        thenActionSequence = ConvertActionSequenceComponents(actionSequenceComponent.thenActionSequence),
                        elseActionSequence = ConvertActionSequenceComponents(actionSequenceComponent.elseActionSequence)
                    });
                }
            }

            return actionSequence;
        }

        public static Type GetType(string typeName)
        {
            var type = Type.GetType(typeName);
            if (type != null) return type;
            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                type = a.GetType(typeName);
                if (type != null)
                    return type;
            }
            return null;
        }
    }


    [Serializable]
    public class ParameterJSON
    {
        public string name;
        public string type;
        public string value;
    }

    [Serializable]
    public class ActionSequenceComponentJSON
    {
        // JsonUtility deserializes to a certain class, no subclasses. Therefore all information about Actions and IfElses have to be saved here, even if only part is used for each component. The rest will stay empty
        // By checking the type later on, we can identify what component it is and use the corresponding information correctly
        public string type;
        public string id;
        public string name;
        public ParameterJSON[] parameters;
        public string variable;
        public string comparisonOperator;
        public string comparison;
        public ActionSequenceComponentJSON[] thenActionSequence;
        public ActionSequenceComponentJSON[] elseActionSequence;
    }
}