using System;
using UnityEditor;
using UnityEngine;
using de.jmu.ge.BuildUtils.Support;


namespace de.jmu.ge.BuildUtils {
    internal static class Utils {
        public static string GetDefaultOutputPath(BuildPlatform platform) => platform switch {
            BuildPlatform.Android => $"{Application.dataPath}/../Build/App.apk",
            BuildPlatform.Linux   => $"{Application.dataPath}/../Build/Linux/App",
            BuildPlatform.Mac     => $"{Application.dataPath}/../Build/MacOS/App.app",
            _                     => $"{Application.dataPath}/../Build/Windows/App.exe",
        };

        public static BuildTarget GetBuildTarget(BuildPlatform platform) => platform switch {
            BuildPlatform.Android => BuildTarget.Android,
            BuildPlatform.Linux   => BuildTarget.StandaloneLinux64,
            BuildPlatform.Mac     => BuildTarget.StandaloneOSX,
            _                     => BuildTarget.StandaloneWindows
        };

        public static BuildPlatform GetBuildPlatform() => Application.platform switch {
            RuntimePlatform.Android       => BuildPlatform.Android,
            RuntimePlatform.LinuxPlayer   => BuildPlatform.Linux,
            RuntimePlatform.LinuxEditor   => BuildPlatform.Linux,
            RuntimePlatform.OSXEditor     => BuildPlatform.Mac,
            RuntimePlatform.OSXPlayer     => BuildPlatform.Mac,
            RuntimePlatform.WindowsPlayer => BuildPlatform.Windows,
            RuntimePlatform.WindowsEditor => BuildPlatform.Windows,
            _                             => throw new ArgumentOutOfRangeException()
        };
    }
}