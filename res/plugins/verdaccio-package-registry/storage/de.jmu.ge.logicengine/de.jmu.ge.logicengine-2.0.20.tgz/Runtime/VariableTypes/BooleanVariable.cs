
using System;

namespace de.jmu.ge.Logic.Runtime
{
    public class BooleanVariable : Variable
    {

        public void Init(string name, bool value){
            Name = name;
            variableType = VariableType.TypeBool;
            BoolValue = value;
        }

        protected override bool handleComparisonInternal(string comparisonOperator, string comparisonValue)
        {
            bool result;
            if (bool.TryParse(comparisonValue, out result)) {
                switch (comparisonOperator)
                {
                    case "=":
                        return BoolValue.Equals(result);
                    case "!=":
                        return !BoolValue.Equals(result);
                    default:
                        throw new ArgumentException("Unknown comparisonOperator", comparisonOperator);
                }
            } else {
                throw new ArgumentException("Compared value has the wrong type", comparisonValue);
            }
        }

    }
}
