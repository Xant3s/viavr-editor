using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using Label = UnityEngine.UIElements.Label;
using Config = de.jmu.ge.Gamification.General.Configuration;
using de.jmu.ge.Gamification.General;
using de.jmu.ge.Logic.Runtime;
using System.Collections.Generic;
#if UNITY_EDITOR
    using UnityEngine.Rendering;
    using de.jmu.ge.viavr.UnityBridge.Core;
    using de.jmu.ge.viavr.UnityBridge.Utils;
#endif

namespace de.jmu.ge.Gamification.UI
{
    public class UiBuilder : MonoBehaviour
    {
#if UNITY_EDITOR
            private readonly ConfigurationProvider<Config> configProvider = 
                new JsonLoader<Config>("Assets/Settings/de.jmu.ge.gamificationutils/Configuration.json");
#endif

        public Variable topLeft;
        public Variable topRight;
        public Variable bottomLeft;
        public Variable bottomRight;
        public UiLabel[] labels = new UiLabel[4];

        [SerializeField] public VisualTreeAsset visualTree;
        private WorldSpaceUIDocument worldSpaceUIDocument;

        private VisualElement root;

        private void OnEnable()
        {
            if (topLeft) topLeft.onValueChange += UpdateVariableValues;
            if (topRight) topRight.onValueChange += UpdateVariableValues;
            if (bottomLeft) bottomLeft.onValueChange += UpdateVariableValues;
            if (bottomRight) bottomRight.onValueChange += UpdateVariableValues;
        }

        private void OnDisable()
        {
            if (topLeft) topLeft.onValueChange -= UpdateVariableValues;
            if (topRight) topRight.onValueChange -= UpdateVariableValues;
            if (bottomLeft) bottomLeft.onValueChange -= UpdateVariableValues;
            if (bottomRight) bottomRight.onValueChange -= UpdateVariableValues;
        }

        private void Awake()
        {
            worldSpaceUIDocument = GetComponent<WorldSpaceUIDocument>();
            worldSpaceUIDocument.onUIDocumentReady.AddListener(InitUi);
        }

#if UNITY_EDITOR
            public void BuildUI() {
                InitUiBuilder();
                InitWorldSpaceUiDocument();
                InitVRCanvas();
                AddAlwaysIncludedShader("Unlit/Transparent");
                AddAlwaysIncludedShader("Unlit/Texture");
            }

            private void InitUiBuilder() {
                // Set Labels[] in Ui Builder
                var configuration = configProvider.GetConfiguration();
                labels = configuration.labels;
                
                // Set Variables in Ui Builder
                foreach(var label in configuration.labels) {
                    var variable = GetVariableByName(label.name);
                    SetVariableAtPosition(variable, label.position);
                }
                
                // Source Asset -> Standard UI
                VisualTreeAsset standardUi = 
                    AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Packages/de.jmu.ge.gamificationutils/Runtime/UI/Resources/StandardUI.uxml");
                visualTree = standardUi;
            }

            private void InitWorldSpaceUiDocument() {
                var worldSpaceUiDocument = GetComponent<WorldSpaceUIDocument>();
                if(!worldSpaceUiDocument)
                    worldSpaceUiDocument = gameObject.AddComponent<WorldSpaceUIDocument>();
                
                // Set good values
                const int panelWidth = 1280;
                var resolution = Screen.currentResolution;
                var width = resolution.width;
                var height = resolution.height;
                worldSpaceUiDocument.PanelWidth = width;
                worldSpaceUiDocument.PanelHeight = height;
                worldSpaceUiDocument.PanelScale = width / panelWidth;
                worldSpaceUiDocument._pixelsPerUnit = width;
                
                // Render Texture -> PanelRenderTexture
                RenderTexture renderTexture = 
                    AssetDatabase.LoadAssetAtPath<RenderTexture>("Packages/de.jmu.ge.gamificationutils/Runtime/UI/Resources/PanelRenderTexture.renderTexture");
                worldSpaceUiDocument.RenderTexturePrefab = renderTexture;
                // Panel Setting -> Default Panel Setting
                PanelSettings panelSetting = 
                    AssetDatabase.LoadAssetAtPath<PanelSettings>("Packages/de.jmu.ge.gamificationutils/Runtime/UI/Resources/DefaultPanelSettings.asset");
                worldSpaceUiDocument.PanelSettingsPrefab = panelSetting;
            }

            private void InitVRCanvas() {
                var vrCanvas = GetComponent<VRCanvas>();
                if(!vrCanvas)
                    vrCanvas = gameObject.AddComponent<VRCanvas>();
                
                // Set good values
                vrCanvas.distance = 1.5f;
                vrCanvas.speed = 10.0f;
            }

            private void AddAlwaysIncludedShader(string shaderName) {
                var shader = Shader.Find(shaderName);
                if (shader == null)
                    return;
                
                var graphicsSettingsObj = AssetDatabase.LoadAssetAtPath<GraphicsSettings>("ProjectSettings/GraphicsSettings.asset");
                var serializedObject = new SerializedObject(graphicsSettingsObj);
                var arrayProp = serializedObject.FindProperty("m_AlwaysIncludedShaders");
                bool hasShader = false;
                for (int i = 0; i < arrayProp.arraySize; ++i)
                {
                    var arrayElem = arrayProp.GetArrayElementAtIndex(i);
                    if (shader == arrayElem.objectReferenceValue)
                    {
                        hasShader = true;
                        break;
                    }
                }

                if (!hasShader) {
                    int arrayIndex = arrayProp.arraySize;
                    arrayProp.InsertArrayElementAtIndex(arrayIndex);
                    var arrayElem = arrayProp.GetArrayElementAtIndex(arrayIndex);
                    arrayElem.objectReferenceValue = shader;
            
                    serializedObject.ApplyModifiedProperties();
            
                    AssetDatabase.SaveAssets();
                }
            }

            private Variable GetVariableByName(string name) {
                var variables = FindAllExistingVariables();
                foreach(var variable in variables.Where(variable => variable.name.Equals(name))) {
                    return variable;
                }
                throw new ArgumentNullException($"No variable found with the name {name}!");
            }

            private List<Variable> FindAllExistingVariables() {
                var path = "Assets/Resources/Variables/";
                var folders = new[] {path};

                var findAssets = AssetDatabase.FindAssets("t: Variable", folders);

                return findAssets.Select(AssetDatabase.GUIDToAssetPath)
                    .Select(AssetDatabase.LoadAssetAtPath<Variable>).ToList();
            }
#endif

        private void InitUi()
        {
            root = GetComponent<UIDocument>().rootVisualElement;
            VisualElement tree = visualTree.CloneTree();
            root.Add(tree);
            InitUiSlots();
            InitStyle();
        }

        private void InitUiSlots()
        {
            SetGameStateNames();
            SetSlotVisibility();
            UpdateVariableValues();
        }

        private void SetGameStateNames()
        {
            if (topLeft) root.Q<Label>("top_left_label").text = topLeft.name;
            if (topRight) root.Q<Label>("top_right_label").text = topRight.name;
            if (bottomLeft) root.Q<Label>("bottom_left_label").text = bottomLeft.name;
            if (bottomRight) root.Q<Label>("bottom_right_label").text = bottomRight.name;
        }

        private void SetSlotVisibility()
        {
            root.Q<VisualElement>("top_left").visible = topLeft != null;
            root.Q<VisualElement>("top_right").visible = topRight != null;
            root.Q<VisualElement>("bottom_left").visible = bottomLeft != null;
            root.Q<VisualElement>("bottom_right").visible = bottomRight != null;
        }

        private void UpdateVariableValues()
        {
            if (topLeft) root.Q<Label>("top_left_value").text = topLeft.GetValue().ToString();
            if (topRight) root.Q<Label>("top_right_value").text = topRight.GetValue().ToString();
            if (bottomLeft) root.Q<Label>("bottom_left_value").text = bottomLeft.GetValue().ToString();
            if (bottomRight) root.Q<Label>("bottom_right_value").text = bottomRight.GetValue().ToString();
        }

        private void InitStyle()
        {
            // Load Basic Style Sheet
            var styleSheet = Resources.Load<StyleSheet>("StandardStyle");
            root.styleSheets.Add(styleSheet);

            // Set Style from Config style
            foreach (var label in labels)
            {
                if (!String.IsNullOrEmpty(label.fontSize)) root.Q<VisualElement>(label.position).style.fontSize = int.Parse(label.fontSize);
                if (!String.IsNullOrEmpty(label.fontColor))
                {
                    ColorUtility.TryParseHtmlString(label.fontColor, out var color);
                    if (!String.IsNullOrEmpty(label.position)) root.Q<VisualElement>(label.position).style.color = color;
                }
            }
        }

        public void SetVariableAtPosition(Variable variable, string position)
        {
            switch (position)
            {
                case "top_left":
                    topLeft = variable;
                    break;
                case "top_right":
                    topRight = variable;
                    break;
                case "bottom_left":
                    bottomLeft = variable;
                    break;
                case "bottom_right":
                    bottomRight = variable;
                    break;
            }
        }
    }
}
