using System;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEngine;


namespace de.jmu.ge.BuildUtils.Support {
    public class ScriptUtils {
        public static void ExecuteShellScript(string input) {
            if(string.IsNullOrWhiteSpace(input)) return;
            var command = ConvertToCommand(input);
            ExecuteCommand(command);
        }

        private static string ConvertToCommand(string input) {
            var projectPath = Application.dataPath.Replace("/", "\\");
            var buildLocation = Path.GetDirectoryName(EditorUserBuildSettings.GetBuildLocation(EditorUserBuildSettings.activeBuildTarget));
            var formattedInput = string.Format(input, projectPath, buildLocation);
            var lines = formattedInput.Split(new[] {"\r\n", "\r", "\n"}, StringSplitOptions.None);
            return string.Join(" && ", lines);
        }

        private static void ExecuteCommand(string bashCommand) {
            var commandLine = new Process();
            var processStartInfo = new ProcessStartInfo {
                WindowStyle = ProcessWindowStyle.Hidden, FileName = "cmd.exe", Arguments = "/C " + bashCommand,
                RedirectStandardError = true, RedirectStandardOutput = true, UseShellExecute = false
            };
            commandLine.StartInfo = processStartInfo;
            commandLine.Start();
            var output = commandLine.StandardOutput.ReadToEnd();
            var errorOutput = commandLine.StandardError.ReadToEnd();
            commandLine.WaitForExit();
            commandLine.Close();
        }
    }
}