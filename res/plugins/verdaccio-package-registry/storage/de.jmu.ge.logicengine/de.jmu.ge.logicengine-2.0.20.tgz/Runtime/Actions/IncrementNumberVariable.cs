using UnityEngine;

namespace de.jmu.ge.Logic.Runtime
{
    public class IncrementNumberVariable : Action
    {
        public void Invoke(ParameterList parameters, LogicEvent logicEvent)
        {
            string variableName = (string)parameters.getParameterValueByName("variable");
            var variable = Resources.Load<NumberVariable>("Variables/" + variableName);

            variable.NumberValue += 1;
        }
    }
}