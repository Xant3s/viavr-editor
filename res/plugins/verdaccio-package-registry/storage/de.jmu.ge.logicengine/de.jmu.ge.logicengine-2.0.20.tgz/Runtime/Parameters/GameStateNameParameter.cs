﻿namespace Parameters
{
    public class GameStateNameParameter : Parameter
    {
        public GameStateNameParameter(string name, string value)
        {
            Name = name;
            parameterType = ParameterType.TypeString;
            StringValue = value;
        }
    }
}